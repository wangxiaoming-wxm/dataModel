"""Champion-style semantic CatBoost adapted for NEW data.

Lessons from old (logic only, no old data):
- No external TE (TE hurt public LB)
- dual_category semantic crosses (order<=3) as CatBoost categoricals
- days/condition multi-scale features
- CatBoost: 900/0.03/depth6/l2=10/rs=0.7/od_wait=120
- 4 seeds 2026-2029, simple average (no OOF weight search)
"""
from __future__ import annotations

import json
import time
from itertools import combinations

import numpy as np
import pandas as pd
from catboost import CatBoostClassifier, Pool
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import StratifiedKFold

from config import N_SPLITS, OUT_DIR, SUB_DIR, TEST_PATH, TRAIN_PATH

SEEDS = [2026, 2027, 2028, 2029]
CROSS_COLS = ["region", "source", "version", "age_range", "month", "livability"]
# also expose t3/condition as category strings (champion config)
EXTRA_CAT = ["t3", "condition_cat"]


def parse_frame(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out["src_car"] = out["source"].astype(str).str.split("|").str[0]
    out["src_eng"] = out["source"].astype(str).str.split("|").str[1]
    t3 = out["t3"].astype(str)
    out["t3_num"] = t3.str.extract(r"^([0-9.]+)", expand=False).astype(float)
    out["t3_suf"] = t3.str.extract(r"([A-Za-z]+)$", expand=False).fillna("NA")
    out["month_n"] = out["month"].astype(str).str.replace("M", "", regex=False).astype(float)
    out["version_n"] = out["version"].astype(str).str.replace("v", "", regex=False).astype(float)
    out["condition_isna"] = out["condition"].isna().astype(int)
    out["condition_filled"] = out["condition"].fillna(-1.0)
    # treat condition/livability as category strings for dual_category style
    out["condition_cat"] = out["condition"].map(lambda x: "NA" if pd.isna(x) else f"{float(x):.6g}")
    out["livability"] = out["livability"].map(lambda x: f"{float(x):.6g}")
    out["age_range"] = out["age_range"].astype(str)
    # vehicle ratios from old features_min
    out["exp_V"] = np.exp(out["V"].clip(upper=20))
    out["ratio_maxg_expV"] = out["max_g"] / out["exp_V"].replace(0, np.nan)
    out["log_maxg_minus_V"] = np.log(out["max_g"].clip(lower=1)) - out["V"]
    out["V_over_cc"] = out["V"] / out["cc"].replace(0, np.nan)
    out["days_over_cond"] = out["days"] / (out["condition"].fillna(out["condition"].median() if out["condition"].notna().any() else 0.6) + 1e-3)
    out["log_days"] = np.log1p(out["days"])
    out["log_cond"] = np.log1p(out["condition_filled"].clip(lower=0))
    return out


def add_days_condition_bins(train: pd.DataFrame, test: pd.DataFrame, bins_list=(5, 10, 20)):
    """Quantile bins fit on train only."""
    train = train.copy()
    test = test.copy()
    for col, name in [("days", "days"), ("condition", "condition")]:
        vals = pd.to_numeric(train[col], errors="coerce")
        med = float(vals.dropna().median()) if vals.notna().any() else 0.0
        train[f"{name}_filled2"] = vals.fillna(med)
        test[f"{name}_filled2"] = pd.to_numeric(test[col], errors="coerce").fillna(med)
        for b in bins_list:
            qs = np.linspace(0, 1, b + 1)
            edges = np.unique(np.nanquantile(train[f"{name}_filled2"], qs))
            if len(edges) < 2:
                edges = np.array([-1e18, 1e18])
            train[f"{name}_qbin_{b}"] = np.digitize(train[f"{name}_filled2"], edges[1:-1], right=True).astype(str)
            test[f"{name}_qbin_{b}"] = np.digitize(test[f"{name}_filled2"], edges[1:-1], right=True).astype(str)
        # interactions
        train[f"{name}_x_log"] = train[f"{name}_filled2"] * np.log1p(train["days"])
        test[f"{name}_x_log"] = test[f"{name}_filled2"] * np.log1p(test["days"])
    train["days_x_cond"] = train["days_filled2"] * train["condition_filled2"]
    test["days_x_cond"] = test["days_filled2"] * test["condition_filled2"]
    train["days_div_cond"] = train["days_filled2"] / (train["condition_filled2"] + 1e-3)
    test["days_div_cond"] = test["days_filled2"] / (test["condition_filled2"] + 1e-3)
    # cat crosses days_bin x region etc
    for b in (5, 10):
        for g in ("region", "source"):
            train[f"dcx_{g}_days{b}"] = train[g].astype(str) + "|" + train[f"days_qbin_{b}"]
            test[f"dcx_{g}_days{b}"] = test[g].astype(str) + "|" + test[f"days_qbin_{b}"]
            train[f"dcx_{g}_cond{b}"] = train[g].astype(str) + "|" + train[f"condition_qbin_{b}"]
            test[f"dcx_{g}_cond{b}"] = test[g].astype(str) + "|" + test[f"condition_qbin_{b}"]
    return train, test


def add_dual_category(train: pd.DataFrame, test: pd.DataFrame):
    """Frequency + semantic crosses fit on train only (unknown -> -1 / 0)."""
    train = train.copy()
    test = test.copy()
    cols = CROSS_COLS + EXTRA_CAT
    for c in cols:
        trv = train[c].astype(str)
        tev = test[c].astype(str)
        vc = trv.value_counts(normalize=True)
        vocab = {v: i for i, v in enumerate(trv.drop_duplicates())}
        train[f"{c}__cat"] = trv
        test[f"{c}__cat"] = tev
        train[f"{c}__code"] = trv.map(vocab).fillna(-1).astype(int)
        test[f"{c}__code"] = tev.map(vocab).fillna(-1).astype(int)
        train[f"{c}__freq"] = trv.map(vc).fillna(0.0)
        test[f"{c}__freq"] = tev.map(vc).fillna(0.0)

    # controlled crosses among first 6 columns, order 2 and 3
    cross_base = CROSS_COLS[:6]
    for order in (2, 3):
        for comb in combinations(cross_base, order):
            name = "X__" + "__".join(comb)
            tr = train[comb[0]].astype(str)
            te = test[comb[0]].astype(str)
            for c in comb[1:]:
                tr = tr + "|" + train[c].astype(str)
                te = te + "|" + test[c].astype(str)
            train[name] = tr
            test[name] = te
    return train, test


def build_xy():
    train_raw = pd.read_csv(TRAIN_PATH)
    test_raw = pd.read_csv(TEST_PATH)
    train = parse_frame(train_raw)
    test = parse_frame(test_raw)
    # fix days_over_cond with train median
    med_c = train["condition"].median()
    train["days_over_cond"] = train["days"] / (train["condition"].fillna(med_c) + 1e-3)
    test["days_over_cond"] = test["days"] / (test["condition"].fillna(med_c) + 1e-3)
    # x19 residual
    from sklearn.linear_model import LinearRegression
    lr = LinearRegression().fit(train[["V"]], train["x19"])
    train["x19_resid_V"] = train["x19"] - lr.predict(train[["V"]])
    test["x19_resid_V"] = test["x19"] - lr.predict(test[["V"]])

    train, test = add_days_condition_bins(train, test)
    train, test = add_dual_category(train, test)

    # livability was stringified; keep numeric copy
    train["livability_num"] = train_raw["livability"].astype(float)
    test["livability_num"] = test_raw["livability"].astype(float)

    cat_cols = [
        "month", "region", "code", "grades", "version", "source",
        "src_car", "src_eng", "t3", "t3_suf",
        "t1", "t2", "r1", "r2", "c1", "c2", "w1", "w2",
        "age_range",
    ]
    # dual cats and crosses
    cat_cols += [c for c in train.columns if c.endswith("__cat") or c.startswith("X__") or c.startswith("dcx_") or c.endswith("_qbin_5") or c.endswith("_qbin_10") or c.endswith("_qbin_20") or c == "condition_cat"]

    num_cols = [
        "days", "cc", "condition_filled", "condition_isna", "t3_num", "V", "max_g",
        "livability_num", "month_n", "version_n",
        "exp_V", "ratio_maxg_expV", "log_maxg_minus_V", "V_over_cc",
        "days_over_cond", "log_days", "log_cond", "days_x_cond", "days_div_cond",
        "days_filled2", "condition_filled2",
        "x19_resid_V",
    ] + [f"x{i}" for i in range(21)]

    # drop duplicate num that might be missing
    num_cols = [c for c in num_cols if c in train.columns]
    cat_cols = [c for c in dict.fromkeys(cat_cols) if c in train.columns]
    feats = num_cols + cat_cols

    X = train[feats].copy()
    Xt = test[feats].copy()
    y = train_raw["label"].astype(int).values
    for c in cat_cols:
        X[c] = X[c].astype(str)
        Xt[c] = Xt[c].astype(str)
    for c in num_cols:
        X[c] = pd.to_numeric(X[c], errors="coerce")
        Xt[c] = pd.to_numeric(Xt[c], errors="coerce")
        med = X[c].median()
        X[c] = X[c].fillna(med)
        Xt[c] = Xt[c].fillna(med)
    return X, Xt, y, cat_cols, test_raw, feats


def cb_params(seed: int) -> dict:
    return dict(
        loss_function="Logloss",
        eval_metric="AUC",
        iterations=900,
        learning_rate=0.03,
        depth=6,
        l2_leaf_reg=10,
        random_strength=0.7,
        od_type="Iter",
        od_wait=120,
        auto_class_weights="Balanced",
        random_seed=seed,
        verbose=False,
        allow_writing_files=False,
    )


def main():
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    SUB_DIR.mkdir(parents=True, exist_ok=True)
    X, Xt, y, cats, test_raw, feats = build_xy()
    print(f"champion feats={len(feats)} cats={len(cats)}", flush=True)

    oofs, preds, aucs = [], [], []
    for seed in SEEDS:
        skf = StratifiedKFold(N_SPLITS, shuffle=True, random_state=seed)
        oof = np.zeros(len(X))
        pred = np.zeros(len(Xt))
        scores = []
        print(f"\n=== seed {seed} ===", flush=True)
        for fold, (tr, va) in enumerate(skf.split(X, y)):
            t0 = time.time()
            model = CatBoostClassifier(**cb_params(seed))
            model.fit(
                Pool(X.iloc[tr], y[tr], cat_features=cats),
                eval_set=Pool(X.iloc[va], y[va], cat_features=cats),
                use_best_model=True,
            )
            oof[va] = model.predict_proba(X.iloc[va])[:, 1]
            pred += model.predict_proba(Xt)[:, 1] / N_SPLITS
            s = roc_auc_score(y[va], oof[va])
            scores.append(float(s))
            print(f"fold{fold} {s:.6f} iter={model.best_iteration_} t={time.time()-t0:.1f}s", flush=True)
        auc = float(roc_auc_score(y, oof))
        print(f"seed{seed} OOF={auc:.6f} mean={np.mean(scores):.6f}±{np.std(scores):.6f}", flush=True)
        oofs.append(oof)
        preds.append(pred)
        aucs.append(auc)
        np.save(OUT_DIR / f"oof_v9_champ_s{seed}.npy", oof)
        np.save(OUT_DIR / f"pred_v9_champ_s{seed}.npy", pred)

    ens_oof = np.mean(oofs, axis=0)
    ens_pred = np.mean(preds, axis=0)
    ens_auc = float(roc_auc_score(y, ens_oof))
    tag = "v9_champion_4seed"
    print(f"CHAMPION 4seed OOF={ens_auc:.6f} seeds={aucs}", flush=True)
    np.save(OUT_DIR / f"oof_{tag}.npy", ens_oof)
    np.save(OUT_DIR / f"pred_{tag}.npy", ens_pred)
    pd.DataFrame({"id": test_raw["id"], "label": ens_pred}).to_csv(SUB_DIR / f"sub_{tag}.csv", index=False)
    meta = {"tag": tag, "oof_auc": ens_auc, "seed_aucs": aucs, "n_features": len(feats), "n_cats": len(cats), "params": "900/0.03/d6/l2=10/rs=0.7"}
    (OUT_DIR / f"meta_{tag}.json").write_text(json.dumps(meta, indent=2, ensure_ascii=False))
    print(json.dumps(meta, indent=2, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
