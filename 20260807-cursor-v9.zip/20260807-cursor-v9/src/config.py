"""Global config for insurance claim prediction."""
from pathlib import Path

ROOT = Path("/Volumes/pssd/app/ml/正式比赛/20260807-cursor")
DATA_DIR = Path("/Volumes/pssd/app/ml/正式比赛/data")

TRAIN_PATH = DATA_DIR / "train.csv"
TEST_PATH = DATA_DIR / "test.csv"
SAMPLE_PATH = DATA_DIR / "submit_sample.csv"

OUT_DIR = ROOT / "outputs"
SUB_DIR = ROOT / "submissions"
DOC_DIR = ROOT / "docs"
LOG_DIR = ROOT / "logs"

N_SPLITS = 5
SEED = 42
SEEDS = [42, 7, 2024]

# CatBoost categorical columns (after FE)
BASE_CAT_COLS = [
    "month",
    "region",
    "t3",
    "code",
    "source",
    "grades",
    "version",
    "t1",
    "t2",
    "r1",
    "r2",
    "c1",
    "c2",
    "w1",
    "w2",
    "age_range",
    "car",
    "eng",
    "t3_suf",
    "t3_bin",
]

# Semantic crosses kept as categorical for CatBoost (no external TE)
SEMANTIC_CROSSES = [
    ("region", "age_range"),
    ("region", "t3_suf"),
    ("region", "code"),
    ("region", "source"),
    ("region", "car"),
    ("code", "age_range"),
    ("source", "age_range"),
    ("code", "source"),
    ("t3_suf", "code"),
    ("month", "code"),
    ("month", "age_range"),
    ("version", "region"),
    ("car", "code"),
    ("grades", "region"),
    ("w1", "w2"),
    ("r1", "r2"),
    ("t1", "t2"),
    ("c1", "c2"),
    ("t3_suf", "age_range"),
    ("region", "grades"),
]
