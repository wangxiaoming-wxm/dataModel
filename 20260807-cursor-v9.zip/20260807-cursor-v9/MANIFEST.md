# 文件清单（V9 审核包）

> 路径均相对本目录根。

## 文档

| 文件 | 必须读？ | 说明 |
|------|----------|------|
| `README.md` | 是 | 审核入口 |
| `docs/09_independent_honesty_audit.md` | 是 | V9 独立诚实性审核 |
| `docs/08_final_review.md` | 是 | V9 阶段最终验收 |
| `docs/00_reviewer_checklist.md` | 可选 | 通用审核清单 |
| `docs/04_experiment_log.md` | 可选 | 全链路分数表（含 V9 前后） |

## 提交

| 文件 | 说明 |
|------|------|
| `submissions/submission.csv` | V9 正式别名（与下者字节相同） |
| `submissions/sub_v9_champion_4seed.csv` | V9 champion 提交 |

SHA256（二者相同）：`2a49cb1241c90c562062ee80b25b4466be18b847ff3c00d64cc9b9fb9b1e0359`

## 冻结产物

| 文件 | 说明 |
|------|------|
| `outputs/meta_v9_champion_4seed.json` | pooled AUC、seed_aucs、超参 |
| `outputs/oof_v9_champion_4seed.npy` | 4-seed 池化 OOF |
| `outputs/pred_v9_champion_4seed.npy` | 4-seed 池化 test（≡ submission） |
| `outputs/oof_v9_champ_s{2026..2029}.npy` | 分 seed OOF |
| `outputs/pred_v9_champ_s{2026..2029}.npy` | 分 seed test |
| `outputs/meta_audit_honest_s2026_foldwise.json` | 折内 FE 校正元数据 |
| `outputs/oof_audit_honest_s2026_foldwise.npy` | seed2026 折内 FE 校正 OOF（0.67703） |

## 源码

| 文件 | 说明 |
|------|------|
| `src/train_champion.py` | **唯一**训练与提交逻辑（FE 内嵌） |
| `src/config.py` | 数据/输出路径与常量 |

## 日志

| 文件 | 说明 |
|------|------|
| `logs/v9_champion.log` | 训练运行日志 |

## 其它

| 文件 | 说明 |
|------|------|
| `requirements.txt` | 依赖声明，无 site-packages |
| `MANIFEST_HASHES.txt` | 全文件 SHA256 |

## 刻意未收录

- `/正式比赛/data` 原始 CSV  
- `__pycache__` / venv / catboost_info  
- `features.py` 及 v0–v8 / stack / tune 脚本（champion 未依赖）  
- V10/V11 与 B5 仓库  
- 大体积无关中间产物
