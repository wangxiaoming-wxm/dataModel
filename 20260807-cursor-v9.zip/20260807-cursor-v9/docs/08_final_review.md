# 最终独立验收报告（Final Review）

> **【历史文档 · V9 阶段】** 主对照为 `v9_champion_4seed`。  
> **当前公开榜提交为 V10（0.70570）**；请改读 [`07_final_report.md`](07_final_report.md)、[`12_v10_report.md`](12_v10_report.md)、[`14_v10_independent_ml_audit.md`](14_v10_independent_ml_audit.md)、[`INDEX.md`](INDEX.md)。

| 项目 | 内容 |
|------|------|
| 轮次 / run_id | Final — 2026-08-07；主对照 `v9_champion_4seed` |
| 审核日期 | 2026-08-07 |
| 对照清单 | `docs/00_reviewer_checklist.md` v1.0 |
| 对照中期 | `docs/05_midterm_review.md`（有条件通过；must-fix：折内 FE） |
| 对照终稿 | `docs/07_final_report.md` |
| 工作目录 | `/Volumes/pssd/app/ml/正式比赛/20260807-cursor` |
| 最终提交 | `submissions/submission.csv` |
| **总评结论** | **有条件通过** |
| 红线项 | **无作弊类红线**；**残留流程性泄漏**（全量 train 频次/分位/中位数在 CV 前 fit，同中期性质、量级更轻） |
| 审核者 | Independent Reviewer（本轮不参与建模实现） |

---

## 1. 总评

**有条件通过。**

- 未发现使用 test 标签、用 `old` 数据训练、外置 TE、人工改分或非概率提交等作弊红线。
- `submission.csv` 格式校验 **100% 通过**，与 `sub_v9_champion_4seed.csv` / `pred_v9_champion_4seed.npy` 数值一致，可作为正式提交文件。
- 宣称 **OOF≈0.6843** 可复核（对 `oof_v9_champion_4seed.npy` 重算 AUC=`0.684342`），相对中期 `v2_lean≈0.6676` 的跃升 **方向合理**；但对外口径应同时披露 **单 seed OOF 均值≈0.6792**（池化袋装乐观约 +0.005）。
- 中期 must-fix「折内特征拟合」**未完全关闭**：champion 管道仍为「全量 train FE → 再 KFold」，频次/分位数/中位数存在轻度流程泄漏。主增益来自语义交叉 + CatBoost 原生类别，泄漏预期影响有限，故不否决提交，但 **不能**宣称「无泄漏认证 OOF」。

---

## 2. 提交格式校验结果

对照 `data/submit_sample.csv` / `test.csv`（6398 行，`id,label`），Python 抽查：

| 检查项 | `submission.csv` | 结果 |
|--------|------------------|------|
| 列名精确 `id,label` | 是 | 通过 |
| 行数 = 6398 | 是 | 通过 |
| `id` 集合 = test / sample | 是 | 通过 |
| `id` 唯一、顺序 = sample | 是 | 通过 |
| `label` 数值、有限、∈[0,1] | min≈0.1409，max≈0.8997 | 通过 |
| 硬 0/1 比例 | 0.0 | 通过 |
| 唯一概率数 | 6398 / 6398 | 通过（非常数/非样例冒充） |
| UTF-8 BOM | 无 | 通过 |
| 与 `submission_final.csv` | 字节级相同 | 一致 |
| 与 `sub_v9_champion_4seed.csv` | 相同 | 同源 |
| 与 `pred_v9_champion_4seed.npy` | max\|Δ\|≈1e-16 | 模型直出 |

**结论：格式合格，建议作为唯一正式提交。**

---

## 3. 是否使用 old 数据训练

| 检查 | 结果 |
|------|------|
| `src/config.py` 数据路径 | 仅指向 `.../正式比赛/data/{train,test}.csv` |
| `src/*.py` 是否 `read_csv` old 路径 | **未发现** |
| 文档表述 | 自研阶段未读 old；达平台后参考 **逻辑/经验**（`docs/06_old_lessons_applied.md`），明确禁止 old CSV/OOF 入模 |
| 终稿声明 | 「未使用 old 数据训练」——与代码一致 |

**判定：未使用 old 数据训练（合规）。** 允许「逻辑对照」；未见把 old train/test/OOF 拼入新训练的证据。

---

## 4. 是否外置 TE / 人工改分

| 检查 | 结果 |
|------|------|
| 外置 Target Encoding | **无**。`train_champion.py` 以 CatBoost 原生类别 + 语义交叉字符串为主；文档明确放弃外置 TE |
| 人工改分 | **无迹象**。`submission.csv` ≡ 脚本写出的 `sub_v9_champion_4seed.csv` ≡ `pred_*.npy`；6398 个互异概率，无个别 id 硬改痕迹 |
| OOF 搜权冲榜 | 终稿与 meta 均为 4-seed **简单平均**，未见搜权 |

**判定：无外置 TE；无人工改分。**

---

## 5. OOF 可信度（中期 0.667 → 最终 0.684）

### 5.1 可复核数字

| 口径 | 数值 | 来源 |
|------|------|------|
| 中期主对照 | ≈0.6676 | `v2_lean` / midterm |
| v9 pooled OOF（4-seed 预测平均后再 AUC） | **0.684342** | `meta_v9_champion_4seed.json` + 本审核重算 |
| v9 单 seed OOF | 0.6780 / 0.6810 / 0.6785 / 0.6792 | `seed_aucs` |
| seed 均值（更诚实） | **≈0.67917** | mean(`seed_aucs`) |
| pooled − seed_mean | **≈+0.0052** | 袋装乐观，与 `06_old_lessons` 记载量级一致 |

### 5.2 跃升是否合理

Δ(pooled)≈**+0.0167**，Δ(诚实 seed 均值)≈**+0.0116**。解释链：

1. **特征配方升级**：自中期 lean（轻量交叉+频次）→ champion（order≤3 语义交叉、days/condition 多尺度、dual_category、车辆比率、`x19_resid_V`），与终稿/实验日志一致，且旧赛同构方案曾带来同量级跃迁——**主因可信**。
2. **多 seed 简单平均**：单 seed 已在 ~0.678–0.681；池化到 0.684 属期望内乐观，**不应把 0.6843 当作单折协议无偏估计**。
3. **非 TE/伪标签路径**：避开了中期与 old 经验中「外置 TE 虚高」路径，跃升机制更干净。
4. **残留流程泄漏**：频次/分位仍在全量 train 上 fit 后进 OOF；抽查 `region` 频次 \|全量−折内\| mean_abs≈**1e-3**，`days_qbin10` 全量 vs 折内分箱不一致率≈**1.5%**——与中期「lean 级轻度泄漏」同级，**预期虚高多半 <~0.005，不足以单独解释 +0.01+ 跃升**。

### 5.3 综合

| 维度 | 判断 |
|------|------|
| 相对中期方向 | **可信**（语义 champion + 多 seed） |
| 0.6843 数字 | **可复核，但偏乐观（池化）**；对外建议报 **seed 均值≈0.679 + pooled≈0.684** |
| 协议合规 | **未达**清单「折内 FE 无泄漏 OOF」；可信度高于中期（配方更强、泄漏仍轻），仍 **非认证冻结分** |
| 文档 | 终稿对防泄漏表述偏满（「仅用 train」未区分 OOF 折内）；实验日志已注明 seed 均值≈0.679——较好 |

---

## 6. 残留风险清单

1. **折内 FE 未闭环（中期 must-fix 遗留）**：`build_xy()` 在 CV 前对全量 train 做频次、分位数边界、中位数填充、`x19~V` 回归；OOF 仍含轻度统计泄漏。
2. **OOF 口径易误读**：对外若只报 0.6843，可能高估 ~0.005；缺 `fold_aucs` / seed×fold 全表。
3. **meta 第 7 节不完整**：`meta_v9_champion_4seed.json` 有 `oof_auc`/`seed_aucs`/`n_features`，**缺** `fold_aucs`、`train_time`（硬件）、submission 路径。
4. **无 `outputs/fold_ids.csv`**：折划分仅由 seed∈{2026–2029} 隐含复现，证据链弱于清单要求。
5. **尚无 Public LB**：无法做 \|OOF−LB\| 黄/红灯；旧赛经验提示本地可能高于公开约 ~0.01。
6. **高基数语义交叉**：order-3 交叉 + 77 类特征，小正类下存在过拟合与折方差风险（seed 间已见 ~0.003 波动）。
7. **可复现性**：已有 `requirements.txt` / README，但本审核未冷启动全量重训验证数值一致性（耗时长）；接受「产物链自洽」级别证据。
8. **备选文件冗余**：`submission_final.csv` / `submission_champ_safe.csv` 与主文件相同——无冲突，但对外应只认一个文件名，避免误传旧版。

---

## 7. 是否建议以 `submission.csv` 作为唯一正式提交

**建议：是。**

理由：
- 格式校验通过，且与 champion 4-seed 推理产物一致；
- 弱模融合已在终稿中证伪（OOF 更低），无需再交 stack/blend；
- `submission_final.csv` 内容相同，保留副本即可，**正式对外只交 `submissions/submission.csv`**。

附带条件（不阻断本枪提交）：
- 对外成绩叙述同时给出 **seed 均值≈0.679**；
- 知晓折内 FE 残留风险；若赛后有时间，应用折内 fit 重跑确认 ΔAUC 是否 ≤0.002。

---

## 8. 分项签核（对照清单 1–8）

| 章节 | 结论 |
|------|------|
| 1 泄漏 | **有条件**（无 TE；模型层合规；统计 FE 仍先全量后拆分） |
| 2 过拟合 | **有条件**（4-seed 稳健；缺 LB；交叉偏丰） |
| 3 作弊红线 | **通过** |
| 4 可复现 | **有条件**（入口与产物齐全；缺 fold_ids / 冷启动复验） |
| 5 文档 | **有条件**（终稿/实验日志基本完整；防泄漏措辞需降调） |
| 6 提交格式 | **通过** |
| 7 每轮指标 | **有条件**（主分数可复核；缺 fold 级与 train_time） |
| 8 可停验收 | **有条件达到「可交一枪」**；未达到「无泄漏认证可停」 |

---

## 9. 审核者签核栏

| 项目 | 内容 |
|------|------|
| 轮次 / run_id | Final / `v9_champion_4seed` → `submissions/submission.csv` |
| 审核日期 | 2026-08-07 |
| 第 1–8 节结论 | **有条件通过** |
| 红线项 | **无**作弊红线；**有**轻度流程泄漏（非一票否决） |
| 审核者签名 | Independent Reviewer |
| 备注 | 批准以 `submission.csv` 为唯一正式提交；OOF 对外建议双口径（0.679 / 0.684）；折内 FE 修复属赛后加分项，非本枪阻断项 |

---

*本报告仅监督验收，不参与建模实现。文档版本：final-review-v1*
