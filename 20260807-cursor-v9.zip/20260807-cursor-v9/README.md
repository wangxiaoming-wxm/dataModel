# V9 独立审核包（历史基线 · champion 4-seed）

> 本目录是从完整工程 **精简抽出** 的只读审核包，供其他大模型 / 人工独立复核。  
> **不含** 数据、虚拟环境、`__pycache__`、消融产物、V10/V11、历史 v0–v8。  
> 内容约 **1.4 MB**（文件字节合计）。

---

## 0. 审核入口（先读这里）

| 优先级 | 文件 | 用途 |
|--------|------|------|
| 1 | 本 `README.md` | 方案边界、目录、复核命令 |
| 2 | `docs/09_independent_honesty_audit.md` | V9 独立诚实性审核（主审核） |
| 3 | `docs/08_final_review.md` | V9 阶段最终验收 |
| 4 | `outputs/meta_v9_champion_4seed.json` | 宣称分数与超参 |
| 5 | `src/train_champion.py` | 唯一训练/提交代码 |

可选：`docs/00_reviewer_checklist.md`、`docs/04_experiment_log.md`。

---

## 1. 一句话结论

**V9** = **语义交叉 CatBoost**，4 seeds（2026–2029）**简单等权平均**，**无外置 TE**、**无连续 OOF 搜权**。

| 口径 | 值 | 角色 |
|------|-----|------|
| 本地池化 OOF | **0.684342** | 可复核，但属 4-seed 池化乐观口径 |
| **建议对外主报** | **seed 均值 ≈ 0.6792** | 更诚实同协议对照 |
| 折内 FE 校正（seed2026） | **0.67703**（相对宣称 0.67804，Δ≈−0.001） | 轻度流程泄漏量级 |
| 公开榜 | （本包为历史基线；公开榜后由 **V10=0.70570** 接替） | 勿与 V10 混报 |

提交文件：`submissions/submission.csv` ≡ `submissions/sub_v9_champion_4seed.csv`  
SHA256：`2a49cb1241c90c562062ee80b25b4466be18b847ff3c00d64cc9b9fb9b1e0359`

---

## 2. 配方要点（审核时盯住这些）

| 项 | 内容 |
|----|------|
| 代码 | `src/train_champion.py`（FE 内嵌；**不** import `features.py`） |
| 模型 | CatBoost Logloss/AUC，`900/0.03/depth6/l2=10/rs=0.7/od_wait=120` |
| CV | StratifiedKFold **5** × seeds **2026–2029** |
| 融合 | 4-seed **简单平均**（`np.mean`） |
| 特征 | dual_category 语义交叉（order≤3）+ days/condition 多尺度；CatBoost 原生类别 |
| TE | **无** |
| 已知问题 | 全量 train 上做分位/中位数等再 CV → **轻度流程泄漏**（非作弊；量级 ~0.001） |

---

## 3. 目录

```
20260807-cursor-v9/
├── README.md
├── MANIFEST.md
├── MANIFEST_HASHES.txt
├── requirements.txt          # 依赖声明（无安装树）
├── docs/                     # 09/08/00/04
├── src/
│   ├── train_champion.py     # V9 唯一训练入口
│   └── config.py             # 路径与常量
├── outputs/                  # OOF / pred / meta / 折内 FE 校正
├── submissions/              # submission.csv ≡ sub_v9_champion_4seed.csv
└── logs/v9_champion.log
```

**刻意排除：** 原始 CSV、venv、`__pycache__`、v0–v8 产物、`features.py`（champion 未使用）、V10/V11、notebooks。

**数据位置（不在本包）：** `/Volumes/pssd/app/ml/正式比赛/data/{train,test,submit_sample}.csv`

---

## 4. 建议审核顺序（给其他大模型）

1. **红线**：伪标签 / test 标签 / 外置 TE / 连续 OOF 搜权 / 旧数据 — 对照 `docs/09`。  
2. **分数复算**：下方脚本核对 pooled / seed 均值 / submission≡pred。  
3. **流程泄漏**：确认 FE 在全量 train 上 fit 再 CV；对照 `oof_audit_honest_s2026_foldwise.npy`（Δ≈−0.001）。  
4. **叙事**：对外主报 **≈0.679**；旁注 pooled=0.684；**不得**把 0.684 说成「最高诚实 OOF」而不加定语。  
5. **定位**：本包是 **历史基线**；当前公开榜主交为 V10（见兄弟目录 `20260807-cursor-v10`）。

---

## 5. 本地复核脚本（只读，不重训）

```bash
python3 - <<'PY'
import json, numpy as np, pandas as pd
from pathlib import Path
from sklearn.metrics import roc_auc_score

ROOT = Path("/Volumes/pssd/app/ml/正式比赛/20260807-cursor-v9")
DATA = Path("/Volumes/pssd/app/ml/正式比赛/data")
y = pd.read_csv(DATA/"train.csv")["label"].astype(int).to_numpy()
meta = json.loads((ROOT/"outputs/meta_v9_champion_4seed.json").read_text())
oof = np.load(ROOT/"outputs/oof_v9_champion_4seed.npy")
pred = np.load(ROOT/"outputs/pred_v9_champion_4seed.npy")
sub = pd.read_csv(ROOT/"submissions/submission.csv")
seeds = [2026, 2027, 2028, 2029]
seed_aucs = [roc_auc_score(y, np.load(ROOT/f"outputs/oof_v9_champ_s{s}.npy")) for s in seeds]
honest = np.load(ROOT/"outputs/oof_audit_honest_s2026_foldwise.npy")

assert abs(roc_auc_score(y, oof) - meta["oof_auc"]) < 1e-12
assert abs(float(np.mean(seed_aucs)) - 0.6791709060496991) < 1e-12
assert np.allclose(sub["label"].to_numpy(), pred)
assert abs(roc_auc_score(y, honest) - 0.6770284751197975) < 1e-12
print("OK pooled", meta["oof_auc"], "seed_mean", float(np.mean(seed_aucs)), "honest_s2026", roc_auc_score(y, honest))
PY
```

源码绝对路径仍指向原工程 `20260807-cursor`；本包用于 **审计阅读与分数复算**，不是一键重训发行版。

---

## 6. 协议红线（方案自述）

1. 仅新数据（无 `old/` 训练）  
2. 无外置 / 全量 Target Encoding 冲分  
3. 无连续 OOF 搜权当诚实分（4-seed 等权）  
4. 无 test 标签 / 伪标签  
5. 须披露：全量 FE→CV 的轻度流程泄漏；对外主报 seed 均值

---

## 7. 来源

抽出自：`/Volumes/pssd/app/ml/正式比赛/20260807-cursor`（`v9_champion_4seed`）  
打包日期：2026-08-07  
角色：**历史基线**（公开榜后由 V10 接替）
