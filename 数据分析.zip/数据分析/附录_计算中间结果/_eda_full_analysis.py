#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Full EDA for car insurance claim prediction — all stats computed, no fabrication."""

import re
import warnings
from itertools import combinations
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats
from sklearn.metrics import roc_auc_score
from sklearn.feature_selection import mutual_info_classif
from sklearn.preprocessing import LabelEncoder

warnings.filterwarnings("ignore")

DATA = Path("/Volumes/pssd/app/ml/正式比赛/data")
OUT = Path("/Volumes/pssd/app/ml/正式比赛/20260807-cursor/agent_data_analyst_report.md")

train = pd.read_csv(DATA / "train.csv")
test = pd.read_csv(DATA / "test.csv")
sample = pd.read_csv(DATA / "submit_sample.csv")
y = train["label"].astype(int)
base_rate = float(y.mean())

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def shannon_entropy(series: pd.Series) -> float:
    vc = series.value_counts(dropna=False)
    p = vc / vc.sum()
    p = p[p > 0]
    return float(-(p * np.log2(p)).sum())


def entropy_ratio(series: pd.Series) -> tuple[float, float, float]:
    h = shannon_entropy(series)
    n = series.nunique(dropna=False)
    hmax = float(np.log2(n)) if n > 1 else 0.0
    ratio = h / hmax if hmax > 0 else 0.0
    return h, hmax, ratio


def zero_rate(s: pd.Series) -> float:
    if pd.api.types.is_numeric_dtype(s):
        return float((s == 0).sum() / len(s))
    return float("nan")


def miss_rate(s: pd.Series) -> float:
    return float(s.isna().mean())


def skew_kurt(s: pd.Series) -> tuple[float, float]:
    s2 = s.dropna()
    if len(s2) < 3 or not pd.api.types.is_numeric_dtype(s2):
        return float("nan"), float("nan")
    return float(s2.skew()), float(s2.kurtosis())


def cohens_d(a: np.ndarray, b: np.ndarray) -> float:
    a, b = np.asarray(a, dtype=float), np.asarray(b, dtype=float)
    a, b = a[~np.isnan(a)], b[~np.isnan(b)]
    if len(a) < 2 or len(b) < 2:
        return float("nan")
    na, nb = len(a), len(b)
    va, vb = a.var(ddof=1), b.var(ddof=1)
    pooled = np.sqrt(((na - 1) * va + (nb - 1) * vb) / (na + nb - 2))
    if pooled == 0:
        return 0.0
    return float((a.mean() - b.mean()) / pooled)


def cliffs_delta(a: np.ndarray, b: np.ndarray, max_n: int = 3000) -> float:
    """Cliff's delta; subsample for speed if large."""
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    a, b = a[~np.isnan(a)], b[~np.isnan(b)]
    if len(a) == 0 or len(b) == 0:
        return float("nan")
    rng = np.random.default_rng(42)
    if len(a) > max_n:
        a = rng.choice(a, max_n, replace=False)
    if len(b) > max_n:
        b = rng.choice(b, max_n, replace=False)
    # efficient via ranking
    # delta = P(a>b) - P(a<b)
    from scipy.stats import mannwhitneyu
    # Use formula based on U
    u, _ = mannwhitneyu(a, b, alternative="two-sided")
    # U = n1*n2 + n1*(n1+1)/2 - R1, but mannwhitneyu returns U for first sample
    # cliffs = 2U/(n1*n2) - 1
    return float(2 * u / (len(a) * len(b)) - 1)


def univariate_auc(x: pd.Series, y: pd.Series) -> float:
    mask = x.notna() & y.notna()
    xv, yv = x[mask].astype(float), y[mask].astype(int)
    if xv.nunique() < 2 or yv.nunique() < 2:
        return float("nan")
    try:
        auc = roc_auc_score(yv, xv)
        return float(max(auc, 1 - auc))  # direction-invariant
    except Exception:
        return float("nan")


def claim_rate_table(df: pd.DataFrame, col: str) -> pd.DataFrame:
    g = df.groupby(col, dropna=False)["label"].agg(["count", "sum", "mean"])
    g.columns = ["n", "claims", "claim_rate"]
    g["lift"] = g["claim_rate"] / base_rate
    return g.sort_values("claim_rate", ascending=False)


def parse_t3(val):
    if pd.isna(val):
        return np.nan, None
    s = str(val).strip()
    m = re.match(r"^([+-]?\d*\.?\d+)\s*([A-Za-z]*)$", s)
    if not m:
        return np.nan, None
    num = float(m.group(1))
    unit = m.group(2) if m.group(2) else None
    return num, unit


def parse_source(val):
    if pd.isna(val):
        return None, None
    parts = str(val).split("|")
    car = parts[0] if len(parts) >= 1 else None
    eng = parts[1] if len(parts) >= 2 else None
    return car, eng


def mi_discrete(x: pd.Series, y: pd.Series) -> float:
    """Mutual information in bits for discrete vars."""
    df = pd.DataFrame({"x": x, "y": y}).dropna()
    if len(df) == 0:
        return float("nan")
    # joint
    ct = pd.crosstab(df["x"], df["y"], normalize=True)
    px = ct.sum(axis=1).values
    py = ct.sum(axis=0).values
    joint = ct.values
    mi = 0.0
    for i in range(joint.shape[0]):
        for j in range(joint.shape[1]):
            pxy = joint[i, j]
            if pxy > 0 and px[i] > 0 and py[j] > 0:
                mi += pxy * np.log2(pxy / (px[i] * py[j]))
    return float(mi)


def encode_for_mi(s: pd.Series) -> np.ndarray:
    le = LabelEncoder()
    filled = s.astype(str).fillna("__NA__")
    return le.fit_transform(filled)


lines: list[str] = []


def w(s=""):
    lines.append(s)


# ---------------------------------------------------------------------------
# Header
# ---------------------------------------------------------------------------
w("# 车险索赔预测 — 极致全面 EDA 摸排报告")
w()
w("> 所有统计均由本脚本对 `train.csv` / `test.csv` / `submit_sample.csv` 亲自计算，禁止编造。")
w("> 任务目标：`label` = 未来一年是否索赔；评估指标：AUC。本报告不含建模提交。")
w()
w("## 0. 数据概览")
w()
w(f"- **train**: {train.shape[0]} 行 × {train.shape[1]} 列；内存 {train.memory_usage(deep=True).sum()/1e6:.2f} MB")
w(f"- **test**: {test.shape[0]} 行 × {test.shape[1]} 列；内存 {test.memory_usage(deep=True).sum()/1e6:.2f} MB")
w(f"- **submit_sample**: {sample.shape[0]} 行 × {sample.shape[1]} 列；`label` 全部为 `{sample['label'].iloc[0]}`")
w(f"- train/test **id 交集**: {len(set(train['id']) & set(test['id']))}（无泄漏重叠）")
w(f"- train id 唯一: {train['id'].nunique()}，重复: {train['id'].duplicated().sum()}")
w(f"- test id 唯一: {test['id'].nunique()}，重复: {test['id'].duplicated().sum()}")
w(f"- sample.id 与 test.id 完全一致: {(sample['id'].values == test['id'].values).all()}")
w(f"- 正负样本: 负类(0)={(y==0).sum()}，正类(1)={(y==1).sum()}，正类率={base_rate:.6f} ({base_rate*100:.4f}%)，不平衡比 1:{(y==0).sum()/max((y==1).sum(),1):.2f}")
w()

# ---------------------------------------------------------------------------
# A. 全字段画像
# ---------------------------------------------------------------------------
w("## A. 全字段画像")
w()
w("对每个字段计算：dtype、cardinality、熵 H、Hmax、H/Hmax、缺失率、零值率、偏度、峰度。")
w()
w("| 字段 | dtype | cardinality | H | Hmax | H/Hmax | 缺失率 | 零值率 | 偏度 | 峰度 |")
w("|---|---|---:|---:|---:|---:|---:|---:|---:|---:|")

feature_cols = [c for c in train.columns if c != "id"]
profile_rows = []
for c in train.columns:
    s = train[c]
    card = int(s.nunique(dropna=False))
    h, hmax, ratio = entropy_ratio(s)
    miss = miss_rate(s)
    zr = zero_rate(s) if pd.api.types.is_numeric_dtype(s) else float("nan")
    sk, ku = skew_kurt(s) if pd.api.types.is_numeric_dtype(s) else (float("nan"), float("nan"))
    profile_rows.append({
        "col": c, "dtype": str(s.dtype), "card": card, "H": h, "Hmax": hmax,
        "ratio": ratio, "miss": miss, "zero": zr, "skew": sk, "kurt": ku,
    })
    zr_s = f"{zr:.6f}" if not np.isnan(zr) else "—"
    sk_s = f"{sk:.4f}" if not np.isnan(sk) else "—"
    ku_s = f"{ku:.4f}" if not np.isnan(ku) else "—"
    w(f"| {c} | {s.dtype} | {card} | {h:.4f} | {hmax:.4f} | {ratio:.4f} | {miss:.6f} | {zr_s} | {sk_s} | {ku_s} |")

w()
w("### A.1 关键要点")
w()
miss_cols = [r for r in profile_rows if r["miss"] > 0]
w(f"- 有缺失的字段数: **{len(miss_cols)}**")
for r in miss_cols:
    w(f"  - `{r['col']}`: 缺失 {r['miss']*100:.4f}%（{(train[r['col']].isna().sum())} 条）")
high_card = sorted([r for r in profile_rows if r["col"] not in ("id", "label")], key=lambda x: -x["card"])[:8]
w("- 高基数（不含 id）Top:")
for r in high_card:
    w(f"  - `{r['col']}`: card={r['card']}, H/Hmax={r['ratio']:.4f}")
near_uniform = [r for r in profile_rows if r["ratio"] > 0.95 and r["card"] > 2 and r["col"] != "id"]
w(f"- 近均匀分布（H/Hmax>0.95, card>2）字段数: {len(near_uniform)}")
low_entropy = [r for r in profile_rows if r["ratio"] < 0.3 and r["col"] not in ("id",) and r["card"] > 1]
w(f"- 低熵比（H/Hmax<0.3）字段: {', '.join(r['col'] for r in low_entropy) if low_entropy else '无'}")
w()

# ---------------------------------------------------------------------------
# B. 目标分析
# ---------------------------------------------------------------------------
w("## B. 目标分析")
w()
w(f"- 正样本 (label=1): **{(y==1).sum()}** / {len(y)} = **{base_rate:.6f}**")
w(f"- 负样本 (label=0): **{(y==0).sum()}** / {len(y)} = **{1-base_rate:.6f}**")
w(f"- 基线 AUC（常数预测）≈ 0.5；基线准确率若全预测负类 ≈ {1-base_rate:.4f}")
w()

group_cols = ["month", "region", "code", "age_range", "grades", "version",
              "c1", "c2", "w1", "w2", "t1", "t2", "r1", "r2"]

w("### B.1 关键分群索赔率热力")
w()
w("热力以「索赔率 / 全局基线」作为 lift；同时给出 n 与 claims。")
w()

for col in group_cols:
    tbl = claim_rate_table(train, col)
    w(f"#### `{col}`（n_levels={len(tbl)}）")
    w()
    w("| 取值 | n | claims | claim_rate | lift |")
    w("|---|---:|---:|---:|---:|")
    for idx, row in tbl.iterrows():
        w(f"| {idx} | {int(row['n'])} | {int(row['claims'])} | {row['claim_rate']:.6f} | {row['lift']:.3f} |")
    # chi2
    ct = pd.crosstab(train[col], train["label"])
    if ct.shape[0] >= 2 and ct.shape[1] == 2:
        chi2, p, dof, _ = stats.chi2_contingency(ct)
        w()
        w(f"- χ²={chi2:.4f}, dof={dof}, p={p:.4e}")
    w()

# ---------------------------------------------------------------------------
# C. 数值字段 vs label
# ---------------------------------------------------------------------------
w("## C. 数值字段 vs label")
w()

num_cols = [
    "days", "cc", "condition", "V", "max_g", "livability", "age_range",
    "x0", "x1", "x2", "x3", "x4", "x5", "x6", "x7", "x8", "x9", "x10",
    "x11", "x12", "x13", "x14", "x15", "x16", "x17", "x18", "x19", "x20",
]
# also include binary-ish as numeric for effect size
extra_num = ["t1", "t2", "r1", "r2", "c1", "c2", "w1", "w2"]

w("### C.1 分位数对比（label=0 vs label=1）与效应量、单变量 AUC")
w()
w("| 字段 | mean0 | mean1 | Δmean | p25_0 | p50_0 | p75_0 | p25_1 | p50_1 | p75_1 | Cohen_d | Cliff_δ | univ_AUC |")
w("|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|")

effect_rows = []
for c in num_cols + extra_num:
    a = train.loc[y == 0, c]
    b = train.loc[y == 1, c]
    m0, m1 = a.mean(), b.mean()
    d = cohens_d(b.values, a.values)  # positive => claimers higher
    cliff = cliffs_delta(b.values, a.values)
    auc = univariate_auc(train[c], y)
    q0 = a.quantile([0.25, 0.5, 0.75])
    q1 = b.quantile([0.25, 0.5, 0.75])
    effect_rows.append({"col": c, "d": d, "cliff": cliff, "auc": auc, "dm": m1 - m0})
    w(
        f"| {c} | {m0:.6g} | {m1:.6g} | {m1-m0:.6g} | "
        f"{q0[0.25]:.6g} | {q0[0.5]:.6g} | {q0[0.75]:.6g} | "
        f"{q1[0.25]:.6g} | {q1[0.5]:.6g} | {q1[0.75]:.6g} | "
        f"{d:.4f} | {cliff:.4f} | {auc:.4f} |"
    )

w()
w("#### 按 |Cohen's d| 排序 Top15")
w()
er = pd.DataFrame(effect_rows).sort_values("d", key=lambda s: s.abs(), ascending=False)
w("| 字段 | Cohen_d | Cliff_δ | univ_AUC | Δmean |")
w("|---|---:|---:|---:|---:|")
for _, r in er.head(15).iterrows():
    w(f"| {r['col']} | {r['d']:.4f} | {r['cliff']:.4f} | {r['auc']:.4f} | {r['dm']:.6g} |")
w()
w("#### 按 univ_AUC 排序 Top15")
w()
er2 = pd.DataFrame(effect_rows).sort_values("auc", ascending=False)
w("| 字段 | univ_AUC | Cohen_d | Cliff_δ |")
w("|---|---:|---:|---:|")
for _, r in er2.head(15).iterrows():
    w(f"| {r['col']} | {r['auc']:.4f} | {r['d']:.4f} | {r['cliff']:.4f} |")
w()

# ---------------------------------------------------------------------------
# D. 信息熵与互信息
# ---------------------------------------------------------------------------
w("## D. 信息熵与互信息")
w()

cat_cols = ["month", "region", "code", "t3", "source", "grades", "version",
            "t1", "t2", "r1", "r2", "c1", "c2", "w1", "w2", "age_range"]

w("### D.1 类别特征熵")
w()
w("| 字段 | card | H(bits) | Hmax | H/Hmax |")
w("|---|---:|---:|---:|---:|")
for c in cat_cols:
    h, hmax, ratio = entropy_ratio(train[c])
    w(f"| {c} | {train[c].nunique(dropna=False)} | {h:.4f} | {hmax:.4f} | {ratio:.4f} |")
w()

w("### D.2 特征–标签互信息（bits，离散 MI；连续特征分箱后计算）")
w()

mi_label = []
# discrete MI for cats
for c in cat_cols:
    mi = mi_discrete(train[c], y)
    mi_label.append({"col": c, "MI": mi, "type": "discrete"})

# continuous: quantile bin then MI
for c in num_cols:
    s = train[c]
    try:
        binned = pd.qcut(s, q=min(20, s.nunique()), duplicates="drop")
        mi = mi_discrete(binned, y)
    except Exception:
        mi = float("nan")
    mi_label.append({"col": c, "MI": mi, "type": "binned"})

# also sklearn MI for continuous (nats -> bits)
X_num = train[num_cols].copy()
# fill condition na with median for sklearn
X_num["condition"] = X_num["condition"].fillna(X_num["condition"].median())
mi_sk = mutual_info_classif(X_num, y, discrete_features=False, random_state=42, n_neighbors=5)
mi_sk_bits = mi_sk / np.log(2)

mi_df = pd.DataFrame(mi_label).sort_values("MI", ascending=False)
w("| 字段 | MI(bits) | 类型 |")
w("|---|---:|---|")
for _, r in mi_df.iterrows():
    w(f"| {r['col']} | {r['MI']:.6f} | {r['type']} |")
w()
w("#### sklearn continuous MI（nats→bits，参考）Top15")
w()
sk_df = pd.DataFrame({"col": num_cols, "MI_bits": mi_sk_bits}).sort_values("MI_bits", ascending=False)
w("| 字段 | MI_sklearn(bits) |")
w("|---|---:|")
for _, r in sk_df.head(15).iterrows():
    w(f"| {r['col']} | {r['MI_bits']:.6f} |")
w()

w("### D.3 特征间互信息（冗余探测）")
w()
w("对主要类别特征两两计算离散 MI，列出 MI 最高的对（潜在冗余）。")
w()

cat_for_pair = ["month", "region", "code", "source", "grades", "version",
                "t1", "t2", "r1", "r2", "c1", "c2", "w1", "w2", "age_range"]
pair_mi = []
for a, b in combinations(cat_for_pair, 2):
    mi = mi_discrete(train[a], train[b])
    # normalize by min(H(a),H(b))
    ha = shannon_entropy(train[a])
    hb = shannon_entropy(train[b])
    nmi = mi / min(ha, hb) if min(ha, hb) > 0 else 0
    pair_mi.append((a, b, mi, nmi, ha, hb))

pair_mi.sort(key=lambda x: -x[2])
w("| feat_A | feat_B | MI(bits) | NMI=MI/min(Ha,Hb) | Ha | Hb |")
w("|---|---|---:|---:|---:|---:|")
for a, b, mi, nmi, ha, hb in pair_mi[:25]:
    w(f"| {a} | {b} | {mi:.6f} | {nmi:.4f} | {ha:.4f} | {hb:.4f} |")
w()

# also numeric corr redundancy for x*
w("#### 数值相关冗余：|ρ|>0.7 的特征对（Pearson）")
w()
num_for_corr = num_cols
corr = train[num_for_corr].corr()
high_pairs = []
for i, a in enumerate(num_for_corr):
    for b in num_for_corr[i + 1:]:
        rho = corr.loc[a, b]
        if abs(rho) >= 0.7:
            high_pairs.append((a, b, float(rho)))
high_pairs.sort(key=lambda x: -abs(x[2]))
if high_pairs:
    w("| feat_A | feat_B | Pearson_ρ |")
    w("|---|---|---:|")
    for a, b, rho in high_pairs:
        w(f"| {a} | {b} | {rho:.4f} |")
else:
    w("- 无 |ρ|≥0.7 的数值对。")
w()

# ---------------------------------------------------------------------------
# E. 隐形关系链
# ---------------------------------------------------------------------------
w("## E. 隐形关系链")
w()

# E1 source
w("### E.1 source 拆解：CAR / ENG 与索赔率")
w()
src = train["source"].apply(parse_source)
train_e = train.copy()
train_e["CAR"] = [p[0] for p in src]
train_e["ENG"] = [p[1] for p in src]
# test parse too later

w(f"- source 原始唯一值: {train['source'].nunique()}")
w(f"- CAR 唯一值: {train_e['CAR'].nunique()} → {sorted(train_e['CAR'].dropna().unique().tolist())}")
w(f"- ENG 唯一值: {train_e['ENG'].nunique()} → {sorted(train_e['ENG'].dropna().unique().tolist())}")
w(f"- CAR|ENG 组合唯一 = source 唯一? {(train_e['CAR']+'|'+train_e['ENG']).nunique() == train['source'].nunique()}")
w()

for col in ["source", "CAR", "ENG"]:
    tbl = claim_rate_table(train_e.assign(label=y) if col != "source" else train, col if col == "source" else col)
    if col != "source":
        tmp = train_e.copy()
        tmp["label"] = y.values
        tbl = claim_rate_table(tmp, col)
    w(f"#### `{col}` 索赔率")
    w()
    w("| 取值 | n | claims | claim_rate | lift |")
    w("|---|---:|---:|---:|---:|")
    for idx, row in tbl.iterrows():
        w(f"| {idx} | {int(row['n'])} | {int(row['claims'])} | {row['claim_rate']:.6f} | {row['lift']:.3f} |")
    w()

# CAR x ENG crosstab claim rate
w("#### CAR × ENG 索赔率矩阵（行=CAR，列=ENG，单元格=claim_rate / n）")
w()
tmp = train_e.copy()
tmp["label"] = y.values
pivot_rate = tmp.pivot_table(index="CAR", columns="ENG", values="label", aggfunc="mean")
pivot_n = tmp.pivot_table(index="CAR", columns="ENG", values="label", aggfunc="count")
w("索赔率:")
w()
w("| CAR \\ ENG | " + " | ".join(str(c) for c in pivot_rate.columns) + " |")
w("|---|" + "|".join(["---:"] * len(pivot_rate.columns)) + "|")
for idx in pivot_rate.index:
    cells = []
    for c in pivot_rate.columns:
        v = pivot_rate.loc[idx, c]
        n = pivot_n.loc[idx, c] if c in pivot_n.columns else np.nan
        if pd.isna(v):
            cells.append("—")
        else:
            cells.append(f"{v:.3f}(n={int(n)})")
    w(f"| {idx} | " + " | ".join(cells) + " |")
w()

# E2 t3
w("### E.2 t3 解析（数值 + 单位）")
w()
parsed = train["t3"].apply(lambda x: parse_t3(x))
train_e["t3_num"] = [p[0] for p in parsed]
train_e["t3_unit"] = [p[1] for p in parsed]
w(f"- t3 原始唯一值: {train['t3'].nunique()}")
w(f"- 解析失败数: {train_e['t3_num'].isna().sum()}")
w(f"- t3_unit 分布: {train_e['t3_unit'].value_counts(dropna=False).to_dict()}")
w(f"- t3_num: min={train_e['t3_num'].min():.6g}, max={train_e['t3_num'].max():.6g}, mean={train_e['t3_num'].mean():.6g}, std={train_e['t3_num'].std():.6g}")
w(f"- t3_num 偏度={train_e['t3_num'].skew():.4f}, 峰度={train_e['t3_num'].kurtosis():.4f}")
w()

tmp = train_e.copy()
tmp["label"] = y.values
tbl = claim_rate_table(tmp, "t3_unit")
w("#### t3_unit 索赔率")
w()
w("| unit | n | claims | claim_rate | lift |")
w("|---|---:|---:|---:|---:|")
for idx, row in tbl.iterrows():
    w(f"| {idx} | {int(row['n'])} | {int(row['claims'])} | {row['claim_rate']:.6f} | {row['lift']:.3f} |")
w()

# t3_num vs label
a = train_e.loc[y == 0, "t3_num"]
b = train_e.loc[y == 1, "t3_num"]
d = cohens_d(b.values, a.values)
auc = univariate_auc(train_e["t3_num"], y)
w(f"- t3_num: mean0={a.mean():.6g}, mean1={b.mean():.6g}, Cohen_d={d:.4f}, univ_AUC={auc:.4f}")
# within unit
w()
w("#### 各 unit 内 t3_num 的 univ_AUC")
w()
w("| unit | n | univ_AUC | Cohen_d |")
w("|---|---:|---:|---:|")
for unit, g in train_e.assign(label=y).groupby("t3_unit"):
    auc_u = univariate_auc(g["t3_num"], g["label"])
    d_u = cohens_d(g.loc[g["label"] == 1, "t3_num"].values, g.loc[g["label"] == 0, "t3_num"].values)
    w(f"| {unit} | {len(g)} | {auc_u:.4f} | {d_u:.4f} |")
w()

# E3 correlations among days/cc/V/condition/max_g/livability
w("### E.3 days / cc / V / condition / max_g / livability 相关与条件依赖")
w()
core = ["days", "cc", "V", "condition", "max_g", "livability"]
sub = train[core].copy()
# spearman & pearson
pear = sub.corr(method="pearson")
spear = sub.corr(method="spearman")
w("#### Pearson 相关矩阵")
w()
w("|  | " + " | ".join(core) + " |")
w("|---|" + "|".join(["---:"] * len(core)) + "|")
for a in core:
    w("| " + a + " | " + " | ".join(f"{pear.loc[a,b]:.4f}" for b in core) + " |")
w()
w("#### Spearman 相关矩阵")
w()
w("|  | " + " | ".join(core) + " |")
w("|---|" + "|".join(["---:"] * len(core)) + "|")
for a in core:
    w("| " + a + " | " + " | ".join(f"{spear.loc[a,b]:.4f}" for b in core) + " |")
w()

# partial correlation style: condition on region (mean claim / feature means)
w("#### 条件依赖探针：按 region 分组后，组内 Spearman(days, V) 等中位数")
w()
intra_corrs = {f"{a}|{b}": [] for a, b in combinations(core, 2)}
for reg, g in train.groupby("region"):
    if len(g) < 30:
        continue
    for a, b in combinations(core, 2):
        ga = g[[a, b]].dropna()
        if len(ga) < 30:
            continue
        rho, _ = stats.spearmanr(ga[a], ga[b])
        intra_corrs[f"{a}|{b}"].append(rho)

w("| 特征对 | 全局Spearman | region内Spearman中位数 | region内IQR | n_regions |")
w("|---|---:|---:|---:|---:|")
for a, b in combinations(core, 2):
    key = f"{a}|{b}"
    vals = np.array(intra_corrs[key])
    if len(vals) == 0:
        continue
    glob = spear.loc[a, b]
    w(f"| {a}–{b} | {glob:.4f} | {np.median(vals):.4f} | {np.percentile(vals,75)-np.percentile(vals,25):.4f} | {len(vals)} |")
w()

# also vs label
w("#### 核心数值 vs label")
w()
w("| 字段 | univ_AUC | Cohen_d | MI_binned |")
w("|---|---:|---:|---:|")
for c in core:
    auc = univariate_auc(train[c], y)
    d = cohens_d(train.loc[y == 1, c].values, train.loc[y == 0, c].values)
    mi = mi_df.loc[mi_df["col"] == c, "MI"]
    mi_v = float(mi.iloc[0]) if len(mi) else float("nan")
    w(f"| {c} | {auc:.4f} | {d:.4f} | {mi_v:.6f} |")
w()

# E4 x0-x20 structure
w("### E.4 x0–x20 内部相关结构（块状 / 低秩）")
w()
xcols = [f"x{i}" for i in range(21)]
X = train[xcols].values
Xc = X - X.mean(axis=0)
# SVD
U, S, Vt = np.linalg.svd(Xc, full_matrices=False)
var_explained = (S ** 2) / (S ** 2).sum()
cumvar = np.cumsum(var_explained)
w(f"- 有效数值秩（奇异值>1e-8）: {(S > 1e-8).sum()} / 21")
w(f"- 前1/3/5/10 主成分累计方差解释: "
  f"{cumvar[0]*100:.2f}% / {cumvar[2]*100:.2f}% / {cumvar[4]*100:.2f}% / {cumvar[9]*100:.2f}%")
w(f"- 条件数 Smax/Smin: {S[0]/S[-1]:.2f}")
w()
w("#### 各主成分方差解释比")
w()
w("| PC | 方差解释比 | 累计 |")
w("|---:|---:|---:|")
for i in range(21):
    w(f"| {i+1} | {var_explained[i]*100:.3f}% | {cumvar[i]*100:.3f}% |")
w()

xcorr = train[xcols].corr()
# block detection: hierarchical-ish by abs corr mean
w("#### |ρ|≥0.5 的 x 特征对")
w()
xpairs = []
for i in range(21):
    for j in range(i + 1, 21):
        rho = xcorr.iloc[i, j]
        if abs(rho) >= 0.5:
            xpairs.append((xcols[i], xcols[j], float(rho)))
xpairs.sort(key=lambda t: -abs(t[2]))
if xpairs:
    w("| A | B | ρ |")
    w("|---|---|---:|")
    for a, b, rho in xpairs[:40]:
        w(f"| {a} | {b} | {rho:.4f} |")
    w(f"- 共 {len(xpairs)} 对 |ρ|≥0.5")
else:
    w("- 无 |ρ|≥0.5 的对")
w()

# average abs corr per x
w("#### 各 xi 与其他 x 的平均 |ρ|")
w()
w("| xi | mean_|ρ| | max_|ρ|_partner | max_|ρ| | univ_AUC_vs_label |")
w("|---|---:|---|---:|---:|")
for i, c in enumerate(xcols):
    others = [abs(xcorr.iloc[i, j]) for j in range(21) if j != i]
    jmax = int(np.argmax([abs(xcorr.iloc[i, j]) if j != i else -1 for j in range(21)]))
    auc = univariate_auc(train[c], y)
    w(f"| {c} | {np.mean(others):.4f} | {xcols[jmax]} | {abs(xcorr.iloc[i,jmax]):.4f} | {auc:.4f} |")
w()

# E5 region co-occurrence
w("### E.5 region 与其他字段的共现")
w()
co_cols = ["month", "code", "grades", "version", "source", "age_range", "c1", "c2", "w1", "w2"]
w("用 Cramér's V 度量 region 与其他类别字段的关联强度。")
w()


def cramers_v(x, y):
    ct = pd.crosstab(x, y)
    chi2, _, _, _ = stats.chi2_contingency(ct)
    n = ct.values.sum()
    r, k = ct.shape
    return float(np.sqrt(chi2 / (n * (min(r, k) - 1)))) if min(r, k) > 1 else 0.0


w("| 字段 | Cramér_V(region, ·) |")
w("|---|---:|")
cramer_list = []
for c in co_cols:
    v = cramers_v(train["region"], train[c])
    cramer_list.append((c, v))
    w(f"| {c} | {v:.4f} |")
w()

# top region x source concentrations
w("#### region × source：各 region 主导 source（占比最高）")
w()
w("| region | n | top_source | top_share | claim_rate |")
w("|---|---:|---|---:|---:|")
for reg, g in train.groupby("region"):
    vc = g["source"].value_counts(normalize=True)
    top_s, share = vc.index[0], vc.iloc[0]
    w(f"| {reg} | {len(g)} | {top_s} | {share:.3f} | {g['label'].mean():.4f} |")
w()

w("#### region × month：各 region 主导 month")
w()
w("| region | n | top_month | top_share |")
w("|---|---:|---|---:|")
for reg, g in train.groupby("region"):
    vc = g["month"].value_counts(normalize=True)
    w(f"| {reg} | {len(g)} | {vc.index[0]} | {vc.iloc[0]:.3f} |")
w()

# ---------------------------------------------------------------------------
# F. 交叉特征候选
# ---------------------------------------------------------------------------
w("## F. 交叉特征候选（交互效应筛查）")
w()
w("方法：对类别特征对 (A,B)，比较观测索赔率与加性假设 "
  "`P≈ clip(P(A)+P(B)-P0, 0, 1)` 的偏离；"
  "用加权平均绝对偏离 + 最小格子样本量过滤，筛出值得做的交叉。")
w()

cross_feats = ["month", "region", "code", "grades", "version", "age_range",
               "c1", "c2", "w1", "w2", "t1", "t2", "r1", "r2", "CAR", "ENG", "t3_unit"]
# ensure CAR ENG t3_unit on train_e
train_x = train.copy()
train_x["CAR"] = train_e["CAR"]
train_x["ENG"] = train_e["ENG"]
train_x["t3_unit"] = train_e["t3_unit"]

cross_results = []
MIN_CELL = 30
for a, b in combinations(cross_feats, 2):
    # skip if same
    g = train_x.groupby([a, b], dropna=False)["label"].agg(["count", "mean"])
    g = g[g["count"] >= MIN_CELL]
    if len(g) < 4:
        continue
    pa = train_x.groupby(a)["label"].mean()
    pb = train_x.groupby(b)["label"].mean()
    deviations = []
    weights = []
    max_dev = 0
    max_dev_cell = None
    for (va, vb), row in g.iterrows():
        add = pa.get(va, base_rate) + pb.get(vb, base_rate) - base_rate
        add = min(max(add, 0.0), 1.0)
        obs = row["mean"]
        dev = obs - add
        deviations.append(abs(dev))
        weights.append(row["count"])
        if abs(dev) > abs(max_dev):
            max_dev = dev
            max_dev_cell = (va, vb, obs, add, int(row["count"]))
    wmean = np.average(deviations, weights=weights)
    cross_results.append({
        "A": a, "B": b, "w_abs_dev": wmean, "n_cells": len(g),
        "max_dev": max_dev, "max_cell": max_dev_cell,
        "total_n": int(g["count"].sum()),
    })

cross_df = pd.DataFrame(cross_results).sort_values("w_abs_dev", ascending=False)
w("### F.1 交互偏离 Top30（加权平均绝对偏离）")
w()
w("| A | B | w_abs_dev | n_cells | max_dev | max_cell(A,B,obs,add,n) |")
w("|---|---|---:|---:|---:|---|")
for _, r in cross_df.head(30).iterrows():
    mc = r["max_cell"]
    mc_s = f"({mc[0]},{mc[1]},obs={mc[2]:.3f},add={mc[3]:.3f},n={mc[4]})" if mc else "—"
    w(f"| {r['A']} | {r['B']} | {r['w_abs_dev']:.5f} | {r['n_cells']} | {r['max_dev']:.4f} | {mc_s} |")
w()

# also numeric interaction: check x features with top cats — skip heavy
# binary pairs synergy via claim rate of AND vs expected
w("### F.2 二元标志交叉（t1/t2/r1/r2/c1/c2/w1/w2）索赔率")
w()
bins = ["t1", "t2", "r1", "r2", "c1", "c2", "w1", "w2"]
w("| A | B | rate_00 | rate_01 | rate_10 | rate_11 | n_11 | expected_11_add | dev_11 |")
w("|---|---|---:|---:|---:|---:|---:|---:|---:|")
bin_cross = []
for a, b in combinations(bins, 2):
    rates = {}
    ns = {}
    for va in [0, 1]:
        for vb in [0, 1]:
            m = (train[a] == va) & (train[b] == vb)
            rates[(va, vb)] = train.loc[m, "label"].mean() if m.sum() else np.nan
            ns[(va, vb)] = int(m.sum())
    pa1 = train.loc[train[a] == 1, "label"].mean()
    pb1 = train.loc[train[b] == 1, "label"].mean()
    exp11 = min(max(pa1 + pb1 - base_rate, 0), 1)
    dev = rates[(1, 1)] - exp11
    bin_cross.append((a, b, abs(dev), dev, rates, ns, exp11))
    w(
        f"| {a} | {b} | {rates[(0,0)]:.4f} | {rates[(0,1)]:.4f} | {rates[(1,0)]:.4f} | {rates[(1,1)]:.4f} | "
        f"{ns[(1,1)]} | {exp11:.4f} | {dev:.4f} |"
    )
w()

# ---------------------------------------------------------------------------
# G. train vs test 一致性
# ---------------------------------------------------------------------------
w("## G. train vs test 一致性检查")
w()

# parse test similarly
test_e = test.copy()
src_t = test["source"].apply(parse_source)
test_e["CAR"] = [p[0] for p in src_t]
test_e["ENG"] = [p[1] for p in src_t]
pt = test["t3"].apply(parse_t3)
test_e["t3_num"] = [p[0] for p in pt]
test_e["t3_unit"] = [p[1] for p in pt]

w("### G.1 类别字段：未见类别 & 分布漂移（TV 距离）")
w()


def total_variation(p: pd.Series, q: pd.Series) -> float:
    idx = p.index.union(q.index)
    pp = p.reindex(idx).fillna(0)
    qq = q.reindex(idx).fillna(0)
    return float(0.5 * (pp - qq).abs().sum())


cat_check = ["month", "region", "code", "t3", "source", "grades", "version",
             "t1", "t2", "r1", "r2", "c1", "c2", "w1", "w2", "age_range"]
w("| 字段 | train_card | test_card | test未见(仅test) | train未见(仅train) | TV距离 |")
w("|---|---:|---:|---|---|---:|")
for c in cat_check:
    tr_set = set(train[c].dropna().unique())
    te_set = set(test[c].dropna().unique())
    only_te = te_set - tr_set
    only_tr = tr_set - te_set
    p = train[c].value_counts(normalize=True, dropna=False)
    q = test[c].value_counts(normalize=True, dropna=False)
    tv = total_variation(p, q)
    only_te_s = ", ".join(map(str, sorted(only_te, key=str)[:10])) or "—"
    if len(only_te) > 10:
        only_te_s += f" …(+{len(only_te)-10})"
    only_tr_s = ", ".join(map(str, sorted(only_tr, key=str)[:10])) or "—"
    if len(only_tr) > 10:
        only_tr_s += f" …(+{len(only_tr)-10})"
    w(f"| {c} | {len(tr_set)} | {len(te_set)} | {only_te_s} | {only_tr_s} | {tv:.4f} |")

# CAR ENG t3_unit
for c in ["CAR", "ENG", "t3_unit"]:
    tr_set = set(train_e[c].dropna().unique())
    te_set = set(test_e[c].dropna().unique())
    only_te = te_set - tr_set
    only_tr = tr_set - te_set
    p = train_e[c].value_counts(normalize=True, dropna=False)
    q = test_e[c].value_counts(normalize=True, dropna=False)
    tv = total_variation(p, q)
    w(f"| {c} | {len(tr_set)} | {len(te_set)} | {', '.join(map(str,sorted(only_te))) or '—'} | {', '.join(map(str,sorted(only_tr))) or '—'} | {tv:.4f} |")
w()

w("### G.2 数值字段：分布与极值范围")
w()
w("| 字段 | train_mean | test_mean | Δmean | train_std | test_std | train_[min,max] | test_[min,max] | test越界比例 | KS_stat | KS_p |")
w("|---|---:|---:|---:|---:|---:|---|---|---:|---:|---:|")

num_check = num_cols + ["t3_num"]
# add t3_num to frames
train_cmp = train.copy()
train_cmp["t3_num"] = train_e["t3_num"]
test_cmp = test.copy()
test_cmp["t3_num"] = test_e["t3_num"]

for c in num_check:
    tr, te = train_cmp[c], test_cmp[c]
    trv, tev = tr.dropna(), te.dropna()
    tmin, tmax = trv.min(), trv.max()
    oob = ((tev < tmin) | (tev > tmax)).mean() if len(tev) else np.nan
    if len(trv) > 0 and len(tev) > 0:
        ks, ksp = stats.ks_2samp(trv, tev)
    else:
        ks, ksp = np.nan, np.nan
    w(
        f"| {c} | {trv.mean():.6g} | {tev.mean():.6g} | {tev.mean()-trv.mean():.6g} | "
        f"{trv.std():.6g} | {tev.std():.6g} | [{tmin:.6g},{tmax:.6g}] | [{tev.min():.6g},{tev.max():.6g}] | "
        f"{oob:.4f} | {ks:.4f} | {ksp:.3e} |"
    )
w()

w("### G.3 缺失模式一致性")
w()
w("| 字段 | train缺失率 | test缺失率 |")
w("|---|---:|---:|")
all_feats = [c for c in test.columns if c != "id"]
for c in all_feats:
    mr_tr = train[c].isna().mean() if c in train.columns else np.nan
    mr_te = test[c].isna().mean()
    if mr_tr > 0 or mr_te > 0:
        w(f"| {c} | {mr_tr:.6f} | {mr_te:.6f} |")
if train["condition"].isna().mean() == 0 and test["condition"].isna().mean() == 0:
    pass
# always show condition
w(f"| condition | {train['condition'].isna().mean():.6f} | {test['condition'].isna().mean():.6f} |")
w()

# ---------------------------------------------------------------------------
# H. 数据质量红旗
# ---------------------------------------------------------------------------
w("## H. 数据质量红旗清单")
w()

flags = []

# missing
if train["condition"].isna().any():
    flags.append(
        f"**condition 缺失**: train {train['condition'].isna().sum()} 条 ({train['condition'].isna().mean()*100:.2f}%), "
        f"test {test['condition'].isna().sum()} 条 ({test['condition'].isna().mean()*100:.2f}%)"
    )

# imbalance
flags.append(f"**类别极不平衡**: 正类率仅 {base_rate*100:.2f}%，AUC 优化时需防刷负类；校准与阈值另议")

# month dominance
m2_share = (train["month"] == "M2").mean()
flags.append(f"**month 严重偏斜**: M2 占 train {(train['month']=='M2').mean()*100:.2f}%（n={(train['month']=='M2').sum()}）")

# w1 w2 complementarity
w_agree = ((train["w1"] + train["w2"]) == 1).mean()
flags.append(f"**w1/w2 近乎互斥互补**: (w1+w2==1) 比例={w_agree:.4f}；冗余度高，交叉需谨慎")

# t1 t2
flags.append(f"**t1/t2**: t1均值={train['t1'].mean():.4f}, t2均值={train['t2'].mean():.4f}；互信息见 D.3")

# condition outliers
cond = train["condition"].dropna()
flags.append(f"**condition 右偏极端**: max={cond.max():.4f}, p99={cond.quantile(0.99):.4f}, p999={cond.quantile(0.999):.4f}, 偏度={cond.skew():.2f}")

# x20 outliers
flags.append(f"**x20 异常上尾**: max={train['x20'].max():.4f}, p99={train['x20'].quantile(0.99):.4f}, 均值={train['x20'].mean():.4f}")

# x18
flags.append(f"**x18 近似对称宽尾**: min={train['x18'].min():.4f}, max={train['x18'].max():.4f}, std={train['x18'].std():.4f}")

# max_g scale
flags.append(f"**max_g 量级巨大**: mean≈{train['max_g'].mean():.0f}, 与其他特征差 5–6 个数量级，树模型外需缩放")

# age_range
ar_vc = train["age_range"].value_counts().sort_index()
flags.append(f"**age_range 分布**: {ar_vc.to_dict()}；高龄档样本量小，索赔率不稳")

# small cells high claim
small_high = []
for col in ["month", "region", "version", "source", "age_range"]:
    tbl = claim_rate_table(train, col)
    for idx, row in tbl.iterrows():
        if row["n"] < 100 and row["claim_rate"] > base_rate * 1.5:
            small_high.append(f"{col}={idx}: n={int(row['n'])}, rate={row['claim_rate']:.3f}")
flags.append("**小样本高索赔率格子**（易过拟合）: " + ("； ".join(small_high[:15]) if small_high else "无显著"))

# id not feature
flags.append("**id 为纯标识**: 唯一且与 test 无交集，禁止入模")

# t3 mixed type
flags.append(f"**t3 为数值+单位混合字符串**: 直接当类别会碎片化（card={train['t3'].nunique()}），应拆 t3_num + t3_unit")

# source composite
flags.append(f"**source 为 CAR|ENG 复合键**: 11 个组合，CAR/ENG 可拆；ENG 与 CAR 似 1:1 绑定需验证")

# check CAR-ENG bijection
car_eng = train_e.groupby("CAR")["ENG"].nunique()
eng_car = train_e.groupby("ENG")["CAR"].nunique()
flags.append(
    f"**CAR↔ENG 映射**: 每 CAR 对应 ENG 数 max={car_eng.max()}；每 ENG 对应 CAR 数 max={eng_car.max()} "
    f"（{'近乎一一对应，拆分增益有限' if car_eng.max()==1 and eng_car.max()==1 else '存在一对多，值得拆'}）"
)

# livability zero
flags.append(f"**livability 零值率**: {(train['livability']==0).mean():.4f}；可能有特殊含义")

# duplicate rows?
dup_feat = train.drop(columns=["id"]).duplicated().sum()
flags.append(f"**除 id 外完全重复行**: {dup_feat}")

# label in features leakage scan
# check if any feature perfectly separates
for c in ["t1", "t2", "r1", "r2", "c1", "c2", "w1", "w2"]:
    # max claim rate by value
    rates = train.groupby(c)["label"].mean()
    if rates.max() > 0.5 or rates.min() < 0.01:
        pass  # just note strong ones later

# version cardinality vs n
flags.append(f"**version 19 类**: 部分版本 n 很小，目标编码易过拟合，需 CV 或平滑")

# region 20
flags.append(f"**region 20 类哈希码**: 语义不明；与 source/month 有共现结构（见 E.5）")

# KS significant drifts
flags.append("**train/test 分布漂移**: 见 G.2 KS 检验；对显著漂移字段做对抗验证或稳健处理")

for i, f in enumerate(flags, 1):
    w(f"{i}. {f}")
w()

# ---------------------------------------------------------------------------
# 预处理建议
# ---------------------------------------------------------------------------
w("## 预处理建议")
w()
w("1. **删除/隔离 `id`**：仅用于提交对齐，不进入特征矩阵。")
w("2. **`condition` 缺失**：train/test 均有缺失；建议 (a) 增加 `condition_isna` 指示；(b) 中位数/区域中位数填充；勿直接删除行（测试集也有缺失）。")
w(f"3. **`t3` 解析**：正则拆成 `t3_num`(float) + `t3_unit`(类别，当前单位集合以实际为准)；原始 `t3` 可弃用或作稀有编码。")
w("4. **`source` 拆分**：解析 `CAR_*` 与 `ENG_*`；若确认一一对应，保留其一即可，否则两者都留并做交叉。")
w("5. **类别编码**：低基数（code/grades/t1/t2/...）One-Hot 或直接作类别；高基数（region/version/t3/source）用目标编码/CatBoost 编码，**必须带折外平滑**防泄漏。")
w("6. **数值缩放**：若用线性/神经网络，对 `max_g`、`days`、`cc`、`x19` 做 StandardScaler/RobustScaler；树模型可跳过。")
w("7. **极值处理**：`condition`、`x20` 上尾可 winsorize 到 p99/p995，或打 log1p（对 condition）；保留「是否极端」指示特征。")
w("8. **不平衡**：训练用 `scale_pos_weight` / `class_weight` / 焦点损失；评估固定 AUC，勿被 Accuracy 误导。")
w("9. **month**：M2 主导，其他月份样本少；可 (a) 保留原字段；(b) 增加 `is_M2`；(c) 稀有月份合并为 `M_other`。")
w("10. **train/test 未见类**：对仅出现在一侧的类别映射到 `UNK`；目标编码用先验平滑。")
w("11. **布尔互补对**：`w1`/`w2` 高度互补，可只留一个或留 `w1` + 交互指示，避免共线膨胀。")
w("12. **类型统一**：`age_range` 虽为 int，语义为有序类别，建议按序类别或分箱保持顺序信息。")
w()

# ---------------------------------------------------------------------------
# 特征工程建议
# ---------------------------------------------------------------------------
w("## 特征工程建议")
w()
w("### 基础派生")
w()
w("- `t3_num`, `t3_unit`, `log1p(t3_num)`")
w("- `CAR`, `ENG`（自 source）")
w("- `condition_isna`, `log1p(condition)`, `condition_rank`")
w("- `is_M2`, `month_ord`（若 M0..M12 有序）")
w("- `x_pca_1..k`（基于 E.4 低秩结构，k 取累计 90% 方差）")
w("- `x_mean`, `x_std`, `x_maxabs`（x0–x20 行统计）")
w("- `max_g_log = log(max_g)`")
w("- 核心比率：`cc/V`, `days/max_g`, `livability/(condition+ε)`（需验证稳定性）")
w()
w("### 交叉特征优先级表")
w()
w("优先级综合：交互偏离 w_abs_dev、单变量强度、样本覆盖、实现成本。")
w()
w("| 优先级 | 交叉 | 理由 | 建议编码 |")
w("|---:|---|---|---|")

# build priority from cross_df top + domain
prio = []
for i, (_, r) in enumerate(cross_df.head(20).iterrows()):
    prio.append((i + 1, r["A"], r["B"], r["w_abs_dev"], r["max_dev"]))

# write top crosses as priority
for rank, (i, a, b, wad, md) in enumerate(prio[:15], 1):
    level = "高" if rank <= 5 else ("中" if rank <= 10 else "低")
    w(f"| {level} | `{a}` × `{b}` | w_abs_dev={wad:.5f}, max_dev={md:.4f} | 目标编码/树原生交叉/显式 concat |")

# always recommend some domain crosses
w("| 高 | `region` × `source`/`CAR` | 共现结构强（E.5），区域风险异质 | 平滑目标编码 |")
w("| 高 | `t3_unit` × `t3_num` | 单位内数值尺度不同 | 分组标准化 + 单位 OHE |")
w("| 中 | `grades` × `code` | 车况等级与代码分群 | OHE 交叉或两字段拼接 |")
w("| 中 | `age_range` × `c1`/`c2` | 年龄与开关类特征 | 拼接类别 |")
w("| 中 | 二元标志 Top 偏离对 | 见 F.2 \|dev_11\| 最大者 | 显式 AND 特征 |")
w("| 低 | `version` × `month` | 版本时间片，小样本多 | 仅高置信组合，其余 UNK |")
w()

# top binary from F.2
bin_cross.sort(key=lambda x: -x[2])
w("#### 二元 AND 特征优先（按 \|dev_11\|）")
w()
w("| 交叉 | \|dev_11\| | dev_11 | n_11 |")
w("|---|---:|---:|---:|")
for a, b, adev, dev, rates, ns, exp11 in bin_cross[:10]:
    w(f"| `{a}=1` AND `{b}=1` | {adev:.4f} | {dev:.4f} | {ns[(1,1)]} |")
w()

w("### x 特征策略")
w()
n90 = int(np.searchsorted(cumvar, 0.90) + 1)
n95 = int(np.searchsorted(cumvar, 0.95) + 1)
w(f"- SVD 显示前 {n90} 个 PC 解释 ≥90% 方差，前 {n95} 个 ≥95%；可考虑 PCA 压缩或嵌入。")
w("- 若存在高相关块（见 E.4），块内可做代表特征或 PCA，减少树分裂稀释。")
w("- 保留对 label univ_AUC 最高的若干原始 xi，与 PC 并存做消融。")
w()

# ---------------------------------------------------------------------------
# 误导性信号
# ---------------------------------------------------------------------------
w("## 需警惕的误导性信号")
w()
w("1. **相关 ≠ 因果**：region/source/version 与索赔率的关联可能由未观测风险因子（驾驶行为、保单筛选）驱动，模型学到的是相关结构，部署分布一变即失效。")
w("2. **小样本高索赔率**：月份非 M2、稀有 version、极端 age_range 的高 lift 极不稳定；单看 lift 会高估特征价值，务必结合 n 与置信区间。")
w("3. **基线正类率 ~10%**：任何「看起来不错」的规则（如某格索赔率 20%）绝对值仍低；AUC 提升来自排序，不要用准确率或「索赔率翻倍」叙事替代。")
w("4. **w1/w2 互补**：高互信息会让「两个特征都重要」的表象出现，实为同一信号的两面；SHAP/重要性会双计。")
w("5. **CAR↔ENG 绑定**：若一一对应，拆分后的「两个强特征」实为重复计数。")
w("6. **t3 当纯类别**：163 水平导致目标编码过拟合；单位与数值混在一起会掩盖真实单调关系。")
w("7. **单变量 AUC 接近 0.5**：弱信号在单变量上「无用」不代表交互后无用，反之单变量强也可能被共线解释掉。")
w("8. **train/test KS 显著**：统计显著 ≠ 实务重要；大样本下微小漂移也显著。应看效应大小（均值差、TV、oob 比例）。")
w("9. **x18/x20 等宽尾**：极端点可劫持线性模型与 MI 估计；树模型相对稳健但仍可能学到伪规则。")
w("10. **对抗验证必要性**：若用 region/month 等能区分 train/test，线上分会乐观；建模前建议做 adversarial validation。")
w("11. **泄漏幻觉**：本数据 test 无 label，且 id 无重叠；但若用全量统计做目标编码再评估同一折，会造成**编码泄漏**，CV 虚高。")
w("12. **condition=10 等截断值**：若存在封顶，分布与缺失可能同源（传感器饱和），简单填均值会扭曲。")
w()

# ---------------------------------------------------------------------------
# 总结
# ---------------------------------------------------------------------------
w("## 总结与建模启示（不含提交）")
w()
top_auc = er2.head(8)["col"].tolist()
top_mi = mi_df.head(8)["col"].tolist()
w(f"- 样本量 train={len(train)}, test={len(test)}；正类率 **{base_rate:.4%}**，指标选 AUC 合理。")
w(f"- 单变量 AUC Top: {', '.join(top_auc)}")
w(f"- 特征-标签 MI Top: {', '.join(top_mi)}")
w("- 最值得立刻做的 FE：`t3` 拆解、`source`→CAR/ENG、`condition` 缺失指示、region 平滑目标编码、x 的 PCA/行统计。")
w("- 交叉优先看 F.1 Top 与 region×source、t3_unit×t3_num。")
w("- 风险：类别不平衡、小格子过拟合、w1/w2 冗余、高基数目标编码泄漏、train/test 漂移。")
w()
w("---")
w(f"*报告生成脚本: `_eda_full_analysis.py`；数据路径: `{DATA}`*")

OUT.write_text("\n".join(lines), encoding="utf-8")
print(f"Wrote {OUT} ({len(lines)} lines)")
print("base_rate", base_rate)
print("top AUC", top_auc)
print("top MI", top_mi[:8])
print("PCA 90%", n90, "95%", n95)
print("CAR-ENG max", car_eng.max(), eng_car.max())
print("high corr pairs", len(high_pairs))
print("x pairs |r|>=0.5", len(xpairs))
print("cross top5:")
print(cross_df.head(5)[["A", "B", "w_abs_dev"]].to_string(index=False))
