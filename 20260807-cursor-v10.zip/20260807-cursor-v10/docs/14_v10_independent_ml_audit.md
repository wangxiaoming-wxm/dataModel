# V10 独立 ML 审核结论（只读复核）

> 审核方：与 V10 实现团队隔离的独立审稿  
> 日期：2026-08-07（**公开榜回写同日**）  
> 范围：作弊红线 + 过拟合/乐观偏差；原审核未改代码、未重训大模型  
> 主产物：`submissions/submission_v10.csv` / `outputs/v10/predictions_v10.npz` / `outputs/v10/meta_v10.json`  
> **公开榜 AUC（用户提交后回报）：0.70570**

---

### 总评（一句话）

**有条件通过（维持）**：未发现作弊红线，宣称 OOF 与提交可精确复算；公开榜 **0.70570** 高于本地嵌套 **0.701315**（上浮约 +0.0044），**下调「上榜必回撤」先验**，但 **≥0.70 本地门禁仍实质依赖 `max` 融合**，对外必须主报嵌套 **0.701315**，公开榜分列，不得把 **0.701751 / 0.70570** 说成“单模/无条件诚实 CV”。

---

### 作弊判定表

| 红线项 | 判定 | 证据 |
|--------|------|------|
| test 含 label / 用 test 标签训练 | **否** | `test.csv` 无 `label` 列；train/test id 重叠 = **0** |
| 伪标签 | **否** | B5 / plus / fuse 管道无 pseudo-label 路径 |
| 全量 / 外置 TE（用全 train 或含 test 统计） | **否** | B5：`target_encoding: none`（`b5_8seed/metrics.json`）；选定 plus：`build_plus` 仅 `root+extra`，**未调用** `te_features`；holdout 上 TE 变体已淘汰（`20260807-codex/push698/out/holdout_results.json`） |
| 用 test 拟合特征/模型 | **否** | B5 `fit_transform(train_fold)` → `transform(va/te)`；plus 阈值/分箱折内 fit |
| 连续 OOF 搜权 | **否** | `fuse_v10.py` 仅离散预注册 6 规则 + 嵌套选规则；无 optuna/连续权重 |
| 旧数据训练 | **否** | B5 `data_sha256` 与当前 `/data/{train,test,submit_sample}.csv` **完全一致**；plus `y` 与当前 train label 一致 |
| 改动 V9 提交 | **否** | `submissions/submission.csv` ≡ `sub_v9_champion_4seed.csv`（sha256 相同：`2a49cb12…e0359`，逐值差 0） |
| 提交与 OOF 管道不一致 / 概率异常 | **否** | submission id = test = sample；`label` ≡ `predictions_v10.npz['test']`；概率 ∈ (0.0256, 0.8834) ⊂ (0,1) |

**作弊结论：否。**

---

### 分数可复核性

独立复算（`sklearn.metrics.roc_auc_score`，与宣称差 = **0**）：

| 口径 | 宣称 | 独立复算 | 备注 |
|------|------|----------|------|
| 选定 pooled `max(B5-12, plus)` | 0.701750795531 | **0.701750795531** | `oof == np.maximum(oof_b5_pool, oof_plus)` |
| 嵌套选规则 OOF（B5-8×plus） | 0.701314965062 | **0.701314965062** | 5 折均选 `max`；`nested_oof == max(b5_8,plus)` |
| B5-8 only | 0.698174537589 | **0.698174537589** | 与 anchor `b5_8seed/predictions.npz` 一致 |
| plus only | 0.688617067477 | **0.688617067477** | 与 `oof_plus_h2_10.npz` 一致 |
| B5-12 pool only | （meta 未单列主报） | **0.698640571174** | 8 + seeds 2034–2037 等权 |
| **公开榜（提交人回报）** | **0.70570** | （外部平台，非本地复算） | 相对嵌套 **+0.0044**；上浮 |

融合对照（B5-8 × plus，独立复算）：

| 规则 | AUC |
|------|-----|
| mean | 0.698871 |
| mean_2_1 | 0.699448 |
| power2 | 0.699401 |
| power3 | 0.699790 |
| **max** | **0.701315** |
| rank_mean | 0.696106 |

嵌套复现：`StratifiedKFold(5, shuffle=True, random_state=42)` → 每折均选 `max`；对 B5-12×plus 嵌套同样五折全选 `max`，嵌套 AUC = full-data max = **0.701751**。

Shuffle sanity（plus OOF 行置换后 × B5-8）：

| 规则 | AUC |
|------|-----|
| max | **0.639599**（崩盘） |
| mean | 0.649363 |
| B5-8 alone | 0.698175 |
| plus shuffled alone | 0.502180 |

→ `max` 增益依赖 plus 的真实排序信号，非空壳投机公式 alone。

提交侧：冻结的 12-seed（2034–2037）重建 `te_b5_12`，`max(te_b5_12, te_plus)` 与 `predictions_v10.npz['test']` / `submission_v10.csv` **逐元素一致**。  
（注：审核时磁盘上已多出 `partial_b5_extra_s2038.npz`；若按现盘 13-seed 重跑会漂移，属冻结风险，不属作弊。）

---

### 过拟合 / 乐观偏差

| 风险源 | 等级 | 说明 |
|--------|------|------|
| 验证集早停（`eval_set` + `use_best_model`） | **轻度** | B5 与 plus 两臂皆有；OOF 略乐观，与既往 B5 审核同型 |
| 多种子池化（B5 8→12；plus 4-seed mean） | **轻度 / 口径** | 池化 AUC ≠ 单 seed；B5 单 seed ≈0.687–0.693，plus 单 seed ≈0.685 |
| **`max` 融合** | **中度** | 预注册集中 **唯一** 明显过 0.70；相对次优 `power3` 约 +0.0015～0.0018。对 AUC 排序有利，对概率校准不利（粗 ECE：B5≈0.009 / max≈0.013；mean(pred) 被抬高到 ~0.107 vs 基率 0.100）。嵌套稳定选中，故非单点巧合，但是 **对本地 OOF 的规则投机面仍在** |
| 异构臂来源（codex `push698` 拷贝） | **轻度** | 字节级与本仓 `outputs/v10/oof_plus_h2_10.npz` 相同；同数据 SHA；TE 未进选定臂。流程上属外部产物接入，复训路径在 `src/v10/train_plus_arm.py` / `plus_features.py` |
| 候选规则“看分后注册” | **轻度** | 代码写明预注册 6 规则；无带时间戳的独立预注册锁。`max` 领先幅度大，难以排除“试过再写进集合”的软怀疑；但嵌套一致 + shuffle 崩盘支持其非纯噪声 |
| 嵌套在 B5-8 上选规则 → 提交用 B5-12 | **轻度** | 协议上略松；独立复算在 B5-12 上嵌套仍全选 `max`，故本次数字风险有限 |
| `load_plus(y)` 按 OOF 挑源 | **无（本次）** | 多源存在时会引入轻度看分选择；当前两源完全相同 |
| 折协议不一致（B5 5-fold vs plus 10-fold） | **轻度** | 异构合理，但融合 OOF 不是同一切分下的严格可比估计 |
| 早停乐观 × max 抬分叠加 | **中度→轻度–中度（公开榜后下调「回撤必现」）** | 本地过 0.70 余量仍薄且依赖 `max`；但公开榜 **0.70570** 实际**上浮**，说明「早停×max 组合必然公榜崩」不成立。校准风险与规则依赖仍在。 |
| 公开榜相对本地 | **利好证据** | 公开 0.70570 − 嵌套 0.701315 ≈ **+0.0044**；不支持「本地虚高主导」叙事，但**不能**因此取消 `max`/早停披露 |

---

### 对外诚实口径建议

**应主报：**

1. **嵌套确认融合 OOF：0.701315**（B5-8 × plus，`max`；五折一致）  
2. **公开榜：0.70570**（与本地分列，勿混为 CV）  
3. 结构：**B5 focus 多种子等权** + **plus（keep x0–x18, H2×10fold×4seed）** + **离散规则嵌套选定的 `max`**  
4. 旁注：冻结 12-seed B5 池 × plus 同规则 → **0.701751**  
5. 明确：两侧均有验证集早停；`max` 改善排序、**不利于概率校准**

**不应这么说：**

- “单模型 / 单 seed 已稳 0.70 / 0.705”  
- “无条件诚实 CV = 0.7018 / 0.7057”  
- “预注册融合普遍过 0.70”（mean/power 族仍 <0.700）  
- “公开榜证明完全无过拟合风险”（上浮降低回撤疑虑，不消除协议条件）

---

### 残留风险与建议动作（最多 5 条）

1. **冻结产物**：以 `predictions_v10.npz` / `meta_v10.json`（12-seed）为提交真源；勿在未更新 meta 时吞入新的 `partial_b5_extra_s2038+.npz`。  
2. **公开榜已验证**：0.70570 支持维持 V10 为主交；若平台允许多版本，B5-8 仍可作为「无 max」对照枪。  
3. **校准对照（可选）**：若后续发现概率类指标/私榜吃校准，可盲比同臂 `power3`/`mean_2_1`（勿 OOF 搜权）。  
4. **plus 可复现性**：用本仓 `src/v10/plus_features.py` 重训核对 OOF≈0.68862（审核当时未重训）。  
5. **口径纪律**：本地默认 **0.7013 + max 披露**；公开榜 **0.70570** 单独写；禁止混用。

---

### 审核方法摘要（可追溯）

- 只读核查：`docs/12_v10_report.md`、`docs/13_v10_honesty_audit.md`、`fuse_v10.py`、`plus_features.py`、`train_plus_arm.py`、`train_b5_focus.py`、B5-8 artifacts、V9 提交对撞  
- Python 独立复算：AUC、嵌套选规则、融合族对比、shuffle、submission↔npz、id/label/概率域、data SHA、臂相关（spearman≈0.95 / pearson≈0.91）  
- 公开榜数字由提交人回报回写（非审核方重提）

**终裁：有条件通过（无作弊；分数可复核；0.70 叙事须绑定 `max` + 嵌套主口径；公开榜 0.70570 为上浮证据）。**
