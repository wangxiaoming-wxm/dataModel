# V10 独立审核包（公开榜 AUC = 0.70570）

> 本目录是从完整工程 **精简抽出** 的只读审核包，供其他大模型 / 人工独立复核。  
> **不含** 数据、虚拟环境、`__pycache__`、消融产物、实验脚本、历史方案。  
> 内容约 **3.5 MB**（文件字节合计）。

---

## 0. 审核入口（先读这里）

| 优先级 | 文件 | 用途 |
|--------|------|------|
| 1 | 本 `README.md` | 方案边界、目录、复核命令 |
| 2 | `docs/12_v10_report.md` | V10 配方与复现说明（主文档） |
| 3 | `docs/14_v10_independent_ml_audit.md` | 已有独立 ML 审核结论 |
| 4 | `docs/13_v10_honesty_audit.md` | 诚实性摘要 |
| 5 | `outputs/v10/meta_v10.json` | 选定标签、候选分数、协议声明 |
| 6 | `src/v10/fuse_v10.py` | 融合与嵌套选规则（提交逻辑核心） |

其余文档：`docs/11_*.md`（B5 臂背景）、`docs/00_*.md`（通用审核清单）。

---

## 1. 一句话结论

**V10** = **B5-focus 12-seed 等权池** × **plus(root_plus, H2, 10 折×4 seed)**，嵌套选定融合规则 **`max`**。  
本地诚实主报：**嵌套 OOF 0.701315**；冻结提交池化：**0.701751**；**公开榜：0.70570**。

| 口径 | 值 | 角色 |
|------|-----|------|
| 公开榜 AUC | **0.70570** | 已提交成绩 |
| 本地嵌套主口径 | **0.701314965** | 对外/答辩诚实主报 |
| 本地冻结池化 | **0.701750796** | `max(B5-12, plus)`，与提交 test 对应 |
| 选定标签 | `b5_12__max__plus` | 见 `meta_v10.json` |

提交文件：`submissions/submission_v10.csv`  
SHA256：`2946e51ec750594afb8a14ebad937059c58460d644f1be6f011d5a9cd7d0f26c`

---

## 2. 双臂结构（审核时盯住这些）

### 臂 A — B5 focus

- 代码：`src/b5/insurance_claim/train_b5_focus.py` + `feature_blocks/`
- 要点：丢 `x0..x18`；`x19`/`x20` 作字符串类别；折内 FE；**无 TE**
- 冻结 OOF：`outputs/b5_8seed/predictions.npz`（8 seed）+ `outputs/v10/partial_b5_extra_s2034..2037.npz` → **12-seed**

### 臂 B — plus / root_plus

- 特征（落盘版）：`src/v10/plus_features.py`
- **实际产出本次 OOF 的训练脚本**：`src/plus_origin/full_train_plus.py` + `src/plus_origin/features.py`  
  （来自 `20260807-codex/push698`，H2 × **10 折** × seeds 2026–2029）
- 冻结：`outputs/v10/oof_plus_h2_10.npz`、`test_plus_h2_10.npy`
- 选定臂 **无 TE**（holdout 上 TE 变体已淘汰）

### 融合

- 代码：`src/v10/fuse_v10.py`
- 预注册离散规则：`mean / mean_2_1 / power2 / power3 / max / rank_mean`（**无连续搜权**）
- 嵌套：`StratifiedKFold(5, shuffle=True, random_state=42)`，五折均选 **`max`**
- 提交：`max(B5-12_pool, plus)` 的 test 概率

---

## 3. 目录（本包全部文件）

```
20260807-cursor-v10/
├── README.md                          # 本文件（审核入口）
├── MANIFEST.md                        # 文件职责清单
├── MANIFEST_HASHES.txt                # SHA256
├── requirements.txt                   # 依赖声明（无安装树）
├── docs/                              # 最新 V10/B5 文档
├── src/
│   ├── v10/                           # 融合 + 落盘特征 + B5 扩种入口
│   ├── b5/insurance_claim/            # B5 臂最小可审代码
│   └── plus_origin/                   # 产出 plus OOF 的原始训练脚本
├── outputs/
│   ├── v10/                           # 冻结 OOF / meta / 预测
│   └── b5_8seed/                      # B5-8 锚点
├── submissions/submission_v10.csv     # 公开榜提交
└── logs/                              # fuse / b5_extra 关键日志
```

**刻意排除：** 训练数据、`venv`、模型权重目录、消融 `ablation_archive`、experimental、V9/V11、完整 b5_repo（含 .git/数据）、notebooks。

**数据位置（不在本包）：** `/Volumes/pssd/app/ml/正式比赛/data/{train,test,submit_sample}.csv`  
B5 metrics 中的 data SHA256 见 `outputs/b5_8seed/metrics.json`。

---

## 4. 建议审核顺序（给其他大模型）

1. **红线**：伪标签 / test 标签 / 全量或外置 TE / 连续 OOF 搜权 / 旧数据 — 对照 `docs/14` 与源码。  
2. **分数复算**：用下方脚本核对本地 OOF 与 submission 对齐（需本机 `data/train.csv`）。  
3. **协议**：确认融合仅离散预注册规则 + 嵌套选择；选定臂无 TE；折内 FE。  
4. **叙事**：公开榜 0.70570 **不得**表述为本地 CV；本地主报嵌套 **0.7013**，并披露 `max` 与早停。  
5. **已知流程缺口**：`src/v10/train_plus_arm.py` 仍引用旧路径 `features`/`gate_tools`（push698 布局），**不能单独跑通**；复训应以 `src/plus_origin/` + 落盘特征 `plus_features.py` 为准。本次提交用的是**冻结 plus OOF**，不依赖当场重训。

---

## 5. 本地复核脚本（只读，不重训）

```bash
# 需能读到比赛 data 目录
python3 - <<'PY'
import json, numpy as np, pandas as pd
from pathlib import Path
from sklearn.metrics import roc_auc_score

ROOT = Path("/Volumes/pssd/app/ml/正式比赛/20260807-cursor-v10")
DATA = Path("/Volumes/pssd/app/ml/正式比赛/data")
y = pd.read_csv(DATA/"train.csv")["label"].astype(int).to_numpy()
meta = json.loads((ROOT/"outputs/v10/meta_v10.json").read_text())
z = np.load(ROOT/"outputs/v10/predictions_v10.npz")
sub = pd.read_csv(ROOT/"submissions/submission_v10.csv")
b5 = np.load(ROOT/"outputs/b5_8seed/predictions.npz")
plus = np.load(ROOT/"outputs/v10/oof_plus_h2_10.npz")["oof"]
parts = sorted((ROOT/"outputs/v10").glob("partial_b5_extra_s*.npz"))
oof12 = (8*b5["oof"] + sum(np.load(p)["oof"] for p in parts)) / (8+len(parts))

assert abs(roc_auc_score(y, z["oof"]) - meta["pooled_oof_auc"]) < 1e-12
assert abs(roc_auc_score(y, np.maximum(b5["oof"], plus)) - meta["nested_oof_auc"]) < 1e-12
assert abs(roc_auc_score(y, np.maximum(oof12, plus)) - meta["pooled_oof_auc"]) < 1e-12
assert np.allclose(sub["label"].to_numpy(), z["test"])
assert meta["public_leaderboard_auc"] == 0.7057
print("OK", meta["selected"], "nested", meta["nested_oof_auc"], "public", meta["public_leaderboard_auc"])
PY
```

源码中的绝对路径仍指向原工程 `20260807-cursor`；**本包用于审计阅读与分数复算**，不是一键重训发行版。重训请回原工程或按 `docs/12` 自行改路径。

---

## 6. 协议红线（方案自述）

1. 仅新数据  
2. 选定臂无外置 / 全量 TE  
3. 折内 FE  
4. 融合仅预注册离散规则 + 嵌套选择（禁止连续 OOF 搜权）  
5. 无 test 标签 / 伪标签  

---

## 7. 来源

抽出自：`/Volumes/pssd/app/ml/正式比赛/20260807-cursor`（V10 正式提交方案）  
打包日期：2026-08-07  
公开榜回报：0.70570
