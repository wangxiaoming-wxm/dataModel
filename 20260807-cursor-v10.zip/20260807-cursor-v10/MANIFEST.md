# 文件清单（审核包）

> 仅列本包内文件职责。路径均相对本目录根。

## 文档

| 文件 | 必须读？ | 说明 |
|------|----------|------|
| `README.md` | 是 | 审核入口、结构、复核命令 |
| `docs/12_v10_report.md` | 是 | V10 详细交付说明 |
| `docs/14_v10_independent_ml_audit.md` | 是 | 独立 ML 审核（含公开榜回写） |
| `docs/13_v10_honesty_audit.md` | 建议 | 诚实性一页摘要 |
| `docs/11_b5_focus_8seed_audit.md` | 建议 | B5 臂背景 |
| `docs/00_reviewer_checklist.md` | 可选 | 通用审核清单 |

## 提交与元数据

| 文件 | 说明 |
|------|------|
| `submissions/submission_v10.csv` | **公开榜提交**（AUC 0.70570） |
| `outputs/v10/meta_v10.json` | 选定项、候选表、协议、公开榜字段 |
| `outputs/v10/predictions_v10.npz` | `oof/test/y` + 分臂 OOF（可复算） |
| `outputs/v10/predictions_v10_max_b5_plus.npz` | `max(B5-8,plus)` 平行冻结 |

## 冻结分臂产物

| 文件 | 说明 |
|------|------|
| `outputs/b5_8seed/predictions.npz` | B5-8seed OOF/test 锚点 |
| `outputs/b5_8seed/metrics.json` | B5-8 指标与 data SHA256 |
| `outputs/v10/partial_b5_extra_s2034.npz` … `2037.npz` | 扩至 B5-12 的 4 个 seed |
| `outputs/v10/oof_plus_h2_10.npz` | plus 臂 OOF |
| `outputs/v10/test_plus_h2_10.npy` | plus 臂 test |

## 源码

| 文件 | 说明 |
|------|------|
| `src/v10/fuse_v10.py` | **融合核心**（嵌套选 `max` → 写提交） |
| `src/v10/plus_features.py` | plus 特征落盘版 |
| `src/v10/train_v10.py` | B5 配方训练入口（含 build_b5 复用） |
| `src/v10/train_v10_batch.py` | B5 extra seeds 批训（2034–2037） |
| `src/v10/train_plus_arm.py` | 落盘训练脚本副本（**导入路径不完整**，见 README §4） |
| `src/plus_origin/features.py` | **实际产出 plus OOF** 的特征代码 |
| `src/plus_origin/full_train_plus.py` | **实际产出 plus OOF** 的训练脚本 |
| `src/b5/insurance_claim/train_b5_focus.py` | B5 focus 主配方 |
| `src/b5/insurance_claim/model.py` | B5 共用工具（audit/submission） |
| `src/b5/insurance_claim/feature_blocks/*` | 折内特征块 |

## 日志（辅助）

| 文件 | 说明 |
|------|------|
| `logs/v10_fuse2.log` | 融合运行输出 |
| `logs/v10_b5_extra.log` | B5 extra seeds 日志 |

## 其它

| 文件 | 说明 |
|------|------|
| `requirements.txt` | 依赖声明，**无** site-packages |
| `MANIFEST_HASHES.txt` | 全文件 SHA256 |

## 刻意未收录

- `/正式比赛/data` 原始 CSV（体积大；SHA 见 B5 metrics）
- `__pycache__` / `.git` / venv / catboost_info
- 消融产物、experimental、V9/V11、完整 b5_repo 其它臂
- 大体积训练过程中间件（除提交冻结所需 npz）
