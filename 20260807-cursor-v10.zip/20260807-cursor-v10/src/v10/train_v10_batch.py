"""Train a tag×seeds batch for V10 (parallelizable)."""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
from catboost import CatBoostClassifier
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import StratifiedKFold

ROOT = Path("/Volumes/pssd/app/ml/正式比赛/20260807-cursor")
sys.path.insert(0, str(ROOT / "external_review" / "b5_repo" / "src"))
sys.path.insert(0, str(ROOT / "src" / "v10"))

from train_v10 import (  # noqa: E402
    OUT,
    PARAMS_B5,
    PARAMS_BAL,
    PARAMS_PLUS,
    build_b5,
    build_b5plus,
)
from builders_v10 import (  # noqa: E402
    build_b5_phys,
    build_b5_phys_t3,
    build_b5_t3cross,
)

DATA = Path("/Volumes/pssd/app/ml/正式比赛/data")
N_SPLITS = 5

BUILDERS = {
    "b5_extra": (build_b5, PARAMS_B5),
    "b5plus": (build_b5plus, PARAMS_PLUS),
    "b5_bal": (build_b5, PARAMS_BAL),
    "b5": (build_b5, PARAMS_B5),
    "b5_phys": (build_b5_phys, PARAMS_B5),
    "b5_t3cross": (build_b5_t3cross, PARAMS_B5),
    "b5_phys_t3": (build_b5_phys_t3, PARAMS_B5),
}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tag", required=True, choices=list(BUILDERS))
    ap.add_argument("--seeds", type=int, nargs="+", required=True)
    args = ap.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)
    builder, params_base = BUILDERS[args.tag]
    train = pd.read_csv(DATA / "train.csv")
    test = pd.read_csv(DATA / "test.csv")
    y = train["label"].astype(int)
    feats = train.drop(columns=["label"])
    oofs, tests, seed_aucs, folds = {}, {}, {}, []
    for seed in args.seeds:
        oof = np.zeros(len(train))
        te = np.zeros(len(test))
        print(f"\n=== {args.tag} seed={seed} ===", flush=True)
        for fold, (a, b) in enumerate(StratifiedKFold(N_SPLITS, shuffle=True, random_state=seed).split(feats, y)):
            t0 = time.time()
            Xtr = feats.iloc[a].reset_index(drop=True)
            Xva = feats.iloc[b].reset_index(drop=True)
            ytr = y.iloc[a].reset_index(drop=True)
            yva = y.iloc[b].reset_index(drop=True)
            tr, va, te_fe, cats = builder(Xtr, Xva, test.copy())
            p = dict(params_base)
            p["random_seed"] = seed + fold
            model = CatBoostClassifier(**p)
            model.fit(tr, ytr, eval_set=(va, yva), cat_features=cats, use_best_model=True, verbose=False)
            oof[b] = model.predict_proba(va)[:, 1]
            te += model.predict_proba(te_fe)[:, 1] / N_SPLITS
            auc = float(roc_auc_score(yva, oof[b]))
            best = model.get_best_iteration()
            folds.append({"seed": seed, "fold": fold, "auc": auc, "best_iter": best})
            print(f"{args.tag} s{seed} f{fold} {auc:.5f} best={best} n={tr.shape[1]} t={time.time()-t0:.1f}s", flush=True)
        sa = float(roc_auc_score(y, oof))
        seed_aucs[str(seed)] = sa
        oofs[seed] = oof
        tests[seed] = te
        np.savez_compressed(OUT / f"partial_{args.tag}_s{seed}.npz", oof=oof, test=te)
        print(f"{args.tag} seed={seed} OOF={sa:.6f}", flush=True)
    pooled_oof = np.mean(np.vstack(list(oofs.values())), axis=0)
    pooled_te = np.mean(np.vstack(list(tests.values())), axis=0)
    meta = {
        "tag": args.tag,
        "seeds": args.seeds,
        "pooled_auc": float(roc_auc_score(y, pooled_oof)),
        "seed_mean": float(np.mean(list(seed_aucs.values()))),
        "seed_std": float(np.std(list(seed_aucs.values()))),
        "seed_aucs": seed_aucs,
        "folds": folds,
    }
    np.savez_compressed(OUT / f"pool_{args.tag}.npz", oof=pooled_oof, test=pooled_te, y=y.to_numpy())
    (OUT / f"meta_{args.tag}.json").write_text(json.dumps(meta, indent=2))
    print(json.dumps(meta, indent=2), flush=True)


if __name__ == "__main__":
    main()
