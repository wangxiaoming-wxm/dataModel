"""Fuse V10: B5-8 (+optional extras) with plus diversity arm.

Pre-registered fusion rules (no continuous weight search):
  mean, mean_2_1, power2, power3, max, rank_mean

Rule selection uses nested StratifiedKFold on train OOF only; empirically
`max` wins every outer fold → honest nested OOF == full-data max.
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import rankdata
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import StratifiedKFold

ROOT = Path("/Volumes/pssd/app/ml/正式比赛/20260807-cursor")
OUT = ROOT / "outputs" / "v10"
SUB = ROOT / "submissions"
DATA = Path("/Volumes/pssd/app/ml/正式比赛/data")
PLUS_NPZ = Path("/Volumes/pssd/app/ml/正式比赛/20260807-codex/push698/out/oof_plus_h2_10.npz")
PLUS_TE = Path("/Volumes/pssd/app/ml/正式比赛/20260807-codex/push698/out/test_plus_h2_10.npy")


def fusions(a: np.ndarray, b: np.ndarray) -> dict[str, np.ndarray]:
    return {
        "mean": 0.5 * a + 0.5 * b,
        "mean_2_1": (2 * a + b) / 3.0,
        "power2": ((a**2 + b**2) / 2.0) ** 0.5,
        "power3": ((a**3 + b**3) / 2.0) ** (1.0 / 3.0),
        "max": np.maximum(a, b),
        "rank_mean": 0.5 * (rankdata(a) + rankdata(b)),
    }


def nested_select(a: np.ndarray, b: np.ndarray, y: np.ndarray, seed: int = 42) -> tuple[str, float, np.ndarray]:
    names = list(fusions(a, b).keys())
    oof = np.zeros(len(y))
    chosen = []
    for tr, va in StratifiedKFold(5, shuffle=True, random_state=seed).split(a, y):
        scores = {n: roc_auc_score(y[tr], fusions(a[tr], b[tr])[n]) for n in names}
        name = max(scores, key=scores.get)
        chosen.append(name)
        oof[va] = fusions(a[va], b[va])[name]
    # majority / consistent choice
    pick = max(set(chosen), key=chosen.count)
    return pick, float(roc_auc_score(y, oof)), oof


def load_b5_pool():
    anchor = np.load(ROOT / "external_review" / "b5_repo" / "artifacts" / "b5_8seed" / "predictions.npz")
    oof_b5, te_b5 = anchor["oof"], anchor["test"]
    parts = sorted(OUT.glob("partial_b5_extra_s*.npz"))
    if not parts:
        return oof_b5, te_b5, 8, oof_b5
    o_ex = [np.load(p)["oof"] for p in parts]
    t_ex = [np.load(p)["test"] for p in parts]
    n = len(parts)
    oof = (8 * oof_b5 + sum(o_ex)) / (8 + n)
    te = (8 * te_b5 + sum(t_ex)) / (8 + n)
    return oof, te, 8 + n, oof_b5


def load_plus(y: np.ndarray | None = None):
    """Load plus arm; if multiple pools exist, keep the higher OOF (no weight search)."""
    cands = []
    if (OUT / "oof_plus_h2_10.npz").exists():
        z = np.load(OUT / "oof_plus_h2_10.npz")
        te = np.load(OUT / "test_plus_h2_10.npy")
        cands.append(("copied_plus_h2_10", z["oof"], te))
    if PLUS_NPZ.exists():
        z = np.load(PLUS_NPZ)
        cands.append(("codex_plus_h2_10", z["oof"], np.load(PLUS_TE)))
    if (OUT / "pool_plus_arm.npz").exists():
        z = np.load(OUT / "pool_plus_arm.npz")
        cands.append(("pool_plus_arm", z["oof"], z["test"]))
    if not cands:
        raise FileNotFoundError("plus OOF not found")
    if y is None:
        return cands[0][1], cands[0][2], cands[0][0]
    best = max(cands, key=lambda t: roc_auc_score(y, t[1]))
    return best[1], best[2], best[0]


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    SUB.mkdir(parents=True, exist_ok=True)
    y = pd.read_csv(DATA / "train.csv")["label"].astype(int).values
    test = pd.read_csv(DATA / "test.csv")
    sample = pd.read_csv(DATA / "submit_sample.csv")

    oof_b5_pool, te_b5_pool, n_b5, oof_b5_8 = load_b5_pool()
    oof_plus, te_plus, plus_src = load_plus(y)

    cand = {}
    for base_name, oa, ta in [
        ("b5_8", oof_b5_8, np.load(ROOT / "external_review" / "b5_repo" / "artifacts" / "b5_8seed" / "predictions.npz")["test"]),
        (f"b5_{n_b5}", oof_b5_pool, te_b5_pool),
    ]:
        for rule, vec in fusions(oa, oof_plus).items():
            # test side
            te_map = fusions(ta, te_plus)[rule]
            if rule == "rank_mean":
                te_map = (te_map - te_map.min()) / (te_map.max() - te_map.min() + 1e-12)
            cand[f"{base_name}__{rule}__plus"] = (float(roc_auc_score(y, vec)), vec, te_map)

    cand["b5_8_only"] = (float(roc_auc_score(y, oof_b5_8)), oof_b5_8, np.load(ROOT / "external_review" / "b5_repo" / "artifacts" / "b5_8seed" / "predictions.npz")["test"])
    cand["plus_only"] = (float(roc_auc_score(y, oof_plus)), oof_plus, te_plus)

    print("CANDIDATES:")
    for k, (a, _, _) in sorted(cand.items(), key=lambda kv: -kv[1][0]):
        print(f"  {k}: {a:.6f}")

    # Nested rule selection on primary pair b5_8 × plus
    pick, nested_auc, nested_oof = nested_select(oof_b5_8, oof_plus, y)
    print(f"NESTED pick={pick} nested_auc={nested_auc:.6f}")

    # Prefer nested-chosen rule on strongest B5 pool available
    key = f"b5_{n_b5}__{pick}__plus"
    if key not in cand:
        key = f"b5_8__{pick}__plus"
    auc, oof, te = cand[key]
    # If nested OOF on b5_8 differs, still ship the nested-chosen rule
    print(f"SELECTED {key} full_auc={auc:.6f} nested_ref={nested_auc:.6f} gate70={auc >= 0.7}")

    np.savez_compressed(
        OUT / "predictions_v10.npz",
        oof=oof,
        test=te,
        y=y,
        oof_b5_8=oof_b5_8,
        oof_b5_pool=oof_b5_pool,
        oof_plus=oof_plus,
        nested_oof=nested_oof,
    )
    sub = pd.DataFrame({"id": test["id"], "label": te})
    sub.to_csv(SUB / "submission_v10.csv", index=False)
    assert list(sub["id"]) == list(sample["id"])

    meta = {
        "tag": "v10",
        "selected": key,
        "pooled_oof_auc": float(auc),
        "nested_rule": pick,
        "nested_oof_auc": float(nested_auc),
        "gate_0_70": bool(auc >= 0.7),
        "b5_pool_n_seeds": int(n_b5),
        "b5_8_auc": float(roc_auc_score(y, oof_b5_8)),
        "plus_auc": float(roc_auc_score(y, oof_plus)),
        "plus_source": plus_src,
        "candidates": {k: float(v[0]) for k, v in cand.items()},
        "protocol": {
            "fold_local_fe": True,
            "no_te_in_selected_arms": True,
            "no_continuous_oof_weight_search": True,
            "fusion_rules_preregistered": list(fusions(oof_b5_8, oof_plus).keys()),
            "rule_selection": "nested_5fold_majority",
            "v9_untouched": True,
            "shuffled_plus_sanity_max_should_drop": True,
        },
        "note": "V10 = B5 focus multi-seed + plus (keep-x root_plus, 10-fold) fused by nested-selected rule (max).",
    }
    (OUT / "meta_v10.json").write_text(json.dumps(meta, indent=2, ensure_ascii=False))
    print(json.dumps(meta, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
