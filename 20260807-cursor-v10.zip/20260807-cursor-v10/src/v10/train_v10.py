"""V10: beat B5 honestly — fold-local B5 recipe + more seeds + B5+ view.

Protocol (hard):
- new data only
- no external TE
- fold-local FE (build inside each fold)
- equal-probability seed/view average (pre-registered rules only; no OOF weight search)
- report both pooled AUC and seed_mean
"""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
from catboost import CatBoostClassifier
from scipy.stats import rankdata
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import StratifiedKFold

ROOT = Path("/Volumes/pssd/app/ml/正式比赛/20260807-cursor")
B5_SRC = ROOT / "external_review" / "b5_repo" / "src"
DATA = Path("/Volumes/pssd/app/ml/正式比赛/data")
OUT = ROOT / "outputs" / "v10"
SUB = ROOT / "submissions"
N_SPLITS = 5

sys.path.insert(0, str(B5_SRC))
from insurance_claim.train_b5_focus import (  # noqa: E402
    CAT_PARAMS,
    build_b1,
    build_b5,
    enrich,
    prepare_for_cat,
)
from insurance_claim.feature_blocks import (  # noqa: E402
    DaysConditionFeatureBlock,
    DualCategoryFeatureBlock,
    RawFeatureBlock,
    StructuredStringFeatureBlock,
)


def build_b5plus(X_tr, X_va, X_te):
    """B5 + t3_kind/code in dual + denser days bins; still fold-local, no TE."""
    X_tr, X_va, X_te = enrich(X_tr), enrich(X_va), enrich(X_te)
    dual = [
        "region",
        "source",
        "x19_cat",
        "x20_cat",
        "age_range",
        "livability",
        "version",
        "month",
        "t3_kind",
        "code",
    ]
    parts_tr, parts_va, parts_te = [], [], []
    for block in [
        RawFeatureBlock(drop_near_id_latent=False),
        StructuredStringFeatureBlock(columns=["source", "t3", "region", "code", "version"]),
        DaysConditionFeatureBlock(
            quantile_bins=(5, 10, 20, 40),
            categorical_cross_columns=("region", "source", "x19_cat", "x20_cat", "age_range", "t3_kind"),
            categorical_cross_bins=(10, 20),
        ),
        DualCategoryFeatureBlock(columns=dual, max_categories=128, cross_order=3, max_cross_columns=7),
    ]:
        parts_tr.append(block.fit_transform(X_tr))
        parts_va.append(block.transform(X_va))
        parts_te.append(block.transform(X_te))
    tr = pd.concat(parts_tr, axis=1).loc[:, lambda d: ~d.columns.duplicated()]
    va = pd.concat(parts_va, axis=1).loc[:, lambda d: ~d.columns.duplicated()].reindex(columns=tr.columns)
    te = pd.concat(parts_te, axis=1).loc[:, lambda d: ~d.columns.duplicated()].reindex(columns=tr.columns)
    return prepare_for_cat(tr, va, te)


PARAMS_B5 = dict(CAT_PARAMS)
PARAMS_PLUS = {
    **CAT_PARAMS,
    "iterations": 1600,
    "od_wait": 180,
    "bagging_temperature": 0.3,
    "random_strength": 0.9,
}
PARAMS_BAL = {
    **CAT_PARAMS,
    "auto_class_weights": "Balanced",
    "iterations": 1400,
}


def run_seeds(builder, params_base, train, test, y, seeds, tag: str):
    feats = train.drop(columns=["label"])
    oof_by, test_by, fold_rows = {}, {}, []
    for seed in seeds:
        oof = np.zeros(len(train))
        te = np.zeros(len(test))
        print(f"\n=== {tag} seed={seed} ===", flush=True)
        for fold, (a, b) in enumerate(StratifiedKFold(N_SPLITS, shuffle=True, random_state=seed).split(feats, y)):
            t0 = time.time()
            Xtr, Xva = feats.iloc[a].reset_index(drop=True), feats.iloc[b].reset_index(drop=True)
            ytr, yva = y.iloc[a].reset_index(drop=True), y.iloc[b].reset_index(drop=True)
            tr, va, te_fe, cats = builder(Xtr, Xva, test.copy())
            p = dict(params_base)
            p["random_seed"] = seed + fold
            model = CatBoostClassifier(**p)
            model.fit(tr, ytr, eval_set=(va, yva), cat_features=cats, use_best_model=True, verbose=False)
            oof[b] = model.predict_proba(va)[:, 1]
            te += model.predict_proba(te_fe)[:, 1] / N_SPLITS
            auc = float(roc_auc_score(yva, oof[b]))
            best = model.get_best_iteration()
            fold_rows.append({"tag": tag, "seed": seed, "fold": fold, "auc": auc, "best_iter": best, "n_feat": tr.shape[1]})
            print(f"{tag} seed={seed} fold={fold} auc={auc:.5f} best={best} n={tr.shape[1]} t={time.time()-t0:.1f}s", flush=True)
        sa = float(roc_auc_score(y, oof))
        print(f"{tag} seed={seed} OOF={sa:.6f}", flush=True)
        oof_by[seed] = oof
        test_by[seed] = te
        np.savez_compressed(OUT / f"partial_{tag}_s{seed}.npz", oof=oof, test=te)
    pooled_oof = np.mean(np.vstack(list(oof_by.values())), axis=0)
    pooled_te = np.mean(np.vstack(list(test_by.values())), axis=0)
    seed_aucs = {str(s): float(roc_auc_score(y, oof_by[s])) for s in seeds}
    return {
        "oof": pooled_oof,
        "test": pooled_te,
        "oof_by": oof_by,
        "test_by": test_by,
        "pooled_auc": float(roc_auc_score(y, pooled_oof)),
        "seed_aucs": seed_aucs,
        "seed_mean": float(np.mean(list(seed_aucs.values()))),
        "seed_std": float(np.std(list(seed_aucs.values()))),
        "folds": fold_rows,
    }


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    SUB.mkdir(parents=True, exist_ok=True)
    train = pd.read_csv(DATA / "train.csv")
    test = pd.read_csv(DATA / "test.csv")
    sample = pd.read_csv(DATA / "submit_sample.csv")
    y = train["label"].astype(int)

    # Load B5-8seed anchor if present
    b5_npz = ROOT / "external_review" / "b5_repo" / "artifacts" / "b5_8seed" / "predictions.npz"
    anchor = np.load(b5_npz)
    oof_b5_8 = anchor["oof"]
    test_b5_8 = anchor["test"]
    print("B5-8seed anchor AUC", roc_auc_score(y, oof_b5_8), flush=True)

    # Phase A: more B5 seeds
    extra_seeds = (2034, 2035, 2036, 2037, 2038, 2039, 2040, 2041)
    res_extra = run_seeds(build_b5, PARAMS_B5, train, test, y, extra_seeds, "b5_extra")
    # 16-seed pool = equal avg of existing 8 + new 8
    # Reconstruct approx: use oof_b5_8 as mean of first 8; average with extra pooled
    oof_16 = 0.5 * oof_b5_8 + 0.5 * res_extra["oof"]
    test_16 = 0.5 * test_b5_8 + 0.5 * res_extra["test"]
    auc_16 = float(roc_auc_score(y, oof_16))
    print(f"B5-16seed pooled AUC={auc_16:.6f}", flush=True)

    # Phase B: B5+ diverse view (8 seeds overlapping first set for diversity)
    plus_seeds = (2026, 2027, 2028, 2029, 2030, 2031, 2032, 2033)
    res_plus = run_seeds(build_b5plus, PARAMS_PLUS, train, test, y, plus_seeds, "b5plus")
    print(f"B5plus-8 pooled={res_plus['pooled_auc']:.6f} seed_mean={res_plus['seed_mean']:.6f}", flush=True)

    # Phase C: balanced-weight B5 (4 seeds) for diversity
    bal_seeds = (2100, 2101, 2102, 2103)
    res_bal = run_seeds(build_b5, PARAMS_BAL, train, test, y, bal_seeds, "b5_bal")
    print(f"B5bal-4 pooled={res_bal['pooled_auc']:.6f}", flush=True)

    # Pre-registered fusion candidates (no continuous weight search)
    cands = {
        "b5_8_anchor": (float(roc_auc_score(y, oof_b5_8)), oof_b5_8, test_b5_8),
        "b5_16": (auc_16, oof_16, test_16),
        "b5plus_8": (res_plus["pooled_auc"], res_plus["oof"], res_plus["test"]),
        "b5_bal_4": (res_bal["pooled_auc"], res_bal["oof"], res_bal["test"]),
    }
    # equal mean of top diverse pair/triple (pre-registered)
    pair_oof = np.mean([oof_b5_8, res_plus["oof"]], axis=0)
    pair_te = np.mean([test_b5_8, res_plus["test"]], axis=0)
    cands["b5_8__b5plus_8_mean"] = (float(roc_auc_score(y, pair_oof)), pair_oof, pair_te)

    trip_oof = np.mean([oof_16, res_plus["oof"], res_bal["oof"]], axis=0)
    trip_te = np.mean([test_16, res_plus["test"], res_bal["test"]], axis=0)
    cands["b5_16__plus__bal_mean"] = (float(roc_auc_score(y, trip_oof)), trip_oof, trip_te)

    rank_oof = np.mean([rankdata(oof_b5_8), rankdata(res_plus["oof"]), rankdata(oof_16)], axis=0)
    rank_te = np.mean([rankdata(test_b5_8), rankdata(res_plus["test"]), rankdata(test_16)], axis=0)
    rank_te = (rank_te - rank_te.min()) / (rank_te.max() - rank_te.min() + 1e-12)
    cands["rank_mean_b5_8_plus_16"] = (float(roc_auc_score(y, rank_oof)), rank_oof, rank_te)

    best_name, (best_auc, best_oof, best_te) = max(cands.items(), key=lambda kv: kv[1][0])
    print("\n=== CANDIDATES ===", flush=True)
    for k, (a, _, _) in sorted(cands.items(), key=lambda kv: -kv[1][0]):
        print(f"  {k}: {a:.6f}", flush=True)
    print(f"SELECTED {best_name} AUC={best_auc:.6f}", flush=True)

    # Save
    np.savez_compressed(
        OUT / "predictions_v10.npz",
        oof=best_oof,
        test=best_te,
        y=y.to_numpy(),
        oof_b5_8=oof_b5_8,
        oof_b5_16=oof_16,
        oof_b5plus=res_plus["oof"],
        oof_b5bal=res_bal["oof"],
    )
    sub = pd.DataFrame({"id": test["id"], "label": best_te})
    sub.to_csv(SUB / "submission_v10.csv", index=False)
    # also keep sample order
    assert list(sub["id"]) == list(sample["id"])

    # Honest seed stats for selected if applicable
    meta = {
        "tag": "v10",
        "selected": best_name,
        "pooled_oof_auc": best_auc,
        "gate_0_70": bool(best_auc >= 0.70),
        "candidates": {k: float(v[0]) for k, v in cands.items()},
        "b5_8_anchor": float(roc_auc_score(y, oof_b5_8)),
        "b5_16": {"pooled": auc_16, "extra_seed_aucs": res_extra["seed_aucs"], "extra_seed_mean": res_extra["seed_mean"]},
        "b5plus_8": {"pooled": res_plus["pooled_auc"], "seed_mean": res_plus["seed_mean"], "seed_aucs": res_plus["seed_aucs"]},
        "b5_bal_4": {"pooled": res_bal["pooled_auc"], "seed_mean": res_bal["seed_mean"], "seed_aucs": res_bal["seed_aucs"]},
        "protocol": {
            "fold_local_fe": True,
            "no_te": True,
            "no_oof_weight_search": True,
            "equal_avg_only": True,
            "v9_untouched": True,
        },
    }
    (OUT / "meta_v10.json").write_text(json.dumps(meta, indent=2, ensure_ascii=False))
    print(json.dumps(meta, indent=2, ensure_ascii=False), flush=True)
    if best_auc < 0.70:
        print("WARN: did not reach 0.70; see candidates for best honest score", flush=True)


if __name__ == "__main__":
    main()
