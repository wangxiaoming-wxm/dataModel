#!/usr/bin/env python3
"""push698 特征构建：root 特征 + E2 新增 + 折内平滑 TE。
所有阈值/分箱/TE 统计只在训练折内 fit。
"""
from __future__ import annotations

import numpy as np
import pandas as pd


def parse_frame(df):
    out = df.copy()
    out["month_n"] = pd.to_numeric(
        out["month"].astype(str).str.replace("M", "", regex=False),
        errors="coerce")
    m = out["t3"].astype(str).str.extract(r"([+-]?\d+(?:\.\d+)?)([A-Za-z]+)?")
    out["t3_num"] = pd.to_numeric(m[0], errors="coerce")
    out["t3_unit"] = m[1].fillna("__none__")
    cm = out["source"].astype(str).str.extract(r"CAR_(\d+)")
    out["car"] = pd.to_numeric(cm[0], errors="coerce")
    out["version_n"] = pd.to_numeric(
        out["version"].astype(str).str.replace("v", "", regex=False),
        errors="coerce")
    out["grades_ord"] = out["grades"].map({"s": 1, "ss": 2, "sss": 3})
    out["age_range8"] = np.where(out["age_range"] >= 8, 8,
                                 out["age_range"]).astype(int)
    return out


def root_features(Xtr, Xva, Xte):
    """与 root_lane/train.py derive_features 等价的基础特征。"""
    def base(df):
        out = pd.DataFrame(index=df.index)
        out["days"] = df["days"].astype(float)
        out["years"] = out["days"] / 365.25
        out["is_new"] = (out["years"] < 1).astype(int)
        out["days_cap30"] = out["days"].clip(upper=30 * 365.25)
        out["over30"] = (out["days"] > 30 * 365.25).astype(int)
        out["condition_isna"] = df["condition"].isna().astype(int)
        out["condition_winsor"] = df["condition"].clip(
            upper=float(Xtr["condition"].quantile(0.99)))
        out["x20_clip"] = df["x20"].clip(
            lower=float(Xtr["x20"].quantile(0.01)),
            upper=float(Xtr["x20"].quantile(0.99)))
        out["x16_clip"] = df["x16"].clip(
            lower=float(Xtr["x16"].quantile(0.01)))
        out["max_g_over_V"] = df["max_g"] / df["V"].replace(0, np.nan)
        out["V_over_cc"] = df["V"] / df["cc"].replace(0, np.nan)
        out["log_max_g"] = np.log1p(df["max_g"])
        out["w_both"] = ((df["w1"] == 1) & (df["w2"] == 1)).astype(int)
        out["w_neither"] = ((df["w1"] == 0) & (df["w2"] == 0)).astype(int)
        out["t2_and_r2"] = ((df["t2"] == 1) & (df["r2"] == 1)).astype(int)
        out["t1_and_c2"] = ((df["t1"] == 1) & (df["c2"] == 1)).astype(int)
        out["age_range8"] = np.where(df["age_range"] >= 8, 8,
                                     df["age_range"]).astype(int)
        for c in ["cc", "condition", "V", "x0", "x1", "x2", "x3", "x4",
                  "x5", "x6", "x7", "x8", "x9", "x10", "x11", "x12",
                  "x13", "x14", "x15", "x16", "x17", "x18", "x20",
                  "t1", "t2", "r1", "r2", "c1", "c2", "w1", "max_g",
                  "age_range", "livability", "month_n", "t3_num", "car",
                  "version_n", "grades_ord"]:
            out[c] = df[c]
        return out

    tr, va, te = base(Xtr), base(Xva), base(Xte)
    edges = np.unique(np.quantile(
        Xtr["days"].astype(float), np.linspace(0, 1, 6)))[1:-1]
    cond_edges = np.unique(np.quantile(
        Xtr["condition"].dropna().astype(float), np.linspace(0, 1, 5)))[1:-1]
    for dfx, out in ((Xtr, tr), (Xva, va), (Xte, te)):
        db = pd.Series(
            np.searchsorted(edges, dfx["days"].astype(float), side="right"),
            index=dfx.index).astype(str)
        cb = pd.Series(
            np.searchsorted(cond_edges,
                            dfx["condition"].astype(float).fillna(
                                Xtr["condition"].median()), side="right"),
            index=dfx.index).astype(str)
        out["days5_x_region"] = (db + "|" + dfx["region"].astype(str)).astype(str)
        out["days5_x_condition4"] = (db + "|" + cb).astype(str)
        out["days5_x_source"] = (db + "|" + dfx["source"].astype(str)).astype(str)
        out["region_x_age8"] = (dfx["region"].astype(str) + "|" +
                                out["age_range8"].astype(str)).astype(str)
        out["region_x_source"] = (dfx["region"].astype(str) + "|" +
                                  dfx["source"].astype(str)).astype(str)
        out["region_x_version"] = (dfx["region"].astype(str) + "|" +
                                   dfx["version"].astype(str)).astype(str)
        out["month"] = dfx["month"].astype(str)
        out["region"] = dfx["region"].astype(str)
        out["source"] = dfx["source"].astype(str)
        out["code"] = dfx["code"].astype(str)
        out["version"] = dfx["version"].astype(str)
        out["t3_unit"] = dfx["t3_unit"].astype(str)
        out["grades"] = dfx["grades"].astype(str)
        out["age_range8"] = out["age_range8"].astype(str)
    cat_names = ["month", "region", "source", "code", "version", "t3_unit",
                 "grades", "age_range8", "days5_x_region",
                 "days5_x_condition4", "days5_x_source",
                 "region_x_age8", "region_x_source", "region_x_version"]
    return tr, va, te, cat_names


def extra_features(tr, va, te, Xtr, Xva, Xte):
    """E2 新增（全部非目标型，阈值折内 fit）。"""
    def add(dfx, out):
        out["w_conflict"] = ((dfx["w1"] + dfx["w2"]) != 1).astype(int)
        unit_med = Xtr.groupby("t3_unit")["t3_num"].transform("median")
        unit_std = Xtr.groupby("t3_unit")["t3_num"].transform("std")
        z = (dfx["t3_num"] - unit_med.reindex(dfx.index).to_numpy()) / \
            unit_std.reindex(dfx.index).to_numpy().clip(min=1e-6)
        out["t3_num_z"] = z
        out["x20_grid"] = np.round(dfx["x20"] / 0.04).astype(int).astype(str)
        out["livability_cat"] = dfx["livability"].astype(str)
        out["region_x_livability"] = (
            dfx["region"].astype(str) + "|" +
            dfx["livability"].astype(str)).astype(str)
        out["days_x_age8"] = (
            dfx["days"].round(-2).astype(int).astype(str) + "|" +
            out["age_range8"].astype(str)).astype(str)
        out["log1p_condition"] = np.log1p(
            dfx["condition"].astype(float).clip(lower=0))
        xs = dfx[[f"x{i}" for i in range(18)]].astype(float)
        out["x_row_mean"] = xs.mean(axis=1)
        out["x_row_std"] = xs.std(axis=1)
        out["x_row_max"] = xs.max(axis=1)
        out["x_row_min"] = xs.min(axis=1)
        out["x_row_abs_mean"] = xs.abs().mean(axis=1)

    add(Xtr, tr)
    add(Xva, va)
    add(Xte, te)
    cats = ["x20_grid", "livability_cat", "region_x_livability",
            "days_x_age8"]
    return tr, va, te, cats


TE_CATS = ["region", "source", "version", "month", "t3", "age_range8",
           "car", "grades", "code"]


def te_features(tr, va, te, Xtr, ytr, Xva, Xte, alpha=50.0, keep_cats=True):
    """折内平滑目标编码：te=(sum_y+prior*alpha)/(count+alpha) + count。
    只对训练折 fit；验证折/test 用训练折统计 transform。"""
    prior = float(ytr.mean())
    te_cols = []
    for c in TE_CATS:
        if c == "car" and "car" not in tr.columns:
            continue
        s_tr = Xtr[c].astype(str).fillna("__MISSING__")
        sums = ytr.groupby(s_tr.to_numpy()).sum()
        cnts = ytr.groupby(s_tr.to_numpy()).count()
        te_map = (sums + prior * alpha) / (cnts + alpha)
        cnt_map = cnts
        for dfx, out in ((Xtr, tr), (Xva, va), (Xte, te)):
            key = dfx[c].astype(str).fillna("__MISSING__")
            out[f"te_{c}"] = key.map(te_map).fillna(prior).astype(float)
            out[f"cnt_{c}"] = key.map(cnt_map).fillna(0).astype(float)
        te_cols += [f"te_{c}", f"cnt_{c}"]
    if keep_cats:
        return tr, va, te, []
    # 替换原生类别：从 cat 名单移除已被 TE 覆盖的列
    return tr, va, te, te_cols


def prepare(tr, va, te, cat_names):
    tr, va, te = tr.copy(), va.copy(), te.copy()
    for c in cat_names:
        for d in (tr, va, te):
            d[c] = d[c].astype(str).fillna("__MISSING__")
    for c in tr.columns:
        if c in cat_names:
            continue
        for d in (tr, va, te):
            d[c] = pd.to_numeric(d[c], errors="coerce")
        med = float(tr[c].median()) if tr[c].notna().any() else 0.0
        tr[c] = tr[c].fillna(med)
        va[c] = va[c].fillna(med)
        te[c] = te[c].fillna(med)
    cat_idx = [tr.columns.get_loc(c) for c in cat_names]
    return tr, va, te, cat_idx


def pca_features(tr, va, te, Xtr, Xva, Xte, n_components=8):
    """折内 StandardScaler + PCA 于 x0-x17；追加 PC 与重构误差。"""
    from sklearn.decomposition import PCA
    from sklearn.preprocessing import StandardScaler

    cols = [f"x{i}" for i in range(18)]
    sc = StandardScaler().fit(Xtr[cols].astype(float))
    pca = PCA(n_components=n_components, random_state=314159).fit(
        sc.transform(Xtr[cols].astype(float)))
    for dfx, out in ((Xtr, tr), (Xva, va), (Xte, te)):
        z = sc.transform(dfx[cols].astype(float))
        pc = pca.transform(z)
        recon = pca.inverse_transform(pc)
        for k in range(n_components):
            out[f"pc_{k}"] = pc[:, k]
        out["pca_recon_err"] = np.mean((z - recon) ** 2, axis=1)
    return tr, va, te


GROUP_COLS = ["region", "source", "version", "month", "grades"]
GROUP_VALUES = ["days", "cc", "V", "max_g", "condition", "t3_num"]


def group_stats_features(tr, va, te, Xtr, Xva, Xte):
    """折内组统计：mean/std/count/dev。映射只由训练折估计。"""
    for g in GROUP_COLS:
        for n in GROUP_VALUES:
            src = (Xtr[n].astype(float).fillna(Xtr[n].median())
                   if n == "condition" else Xtr[n].astype(float))
            key_tr = Xtr[g].astype(str)
            mean_map = src.groupby(key_tr).mean()
            std_map = src.groupby(key_tr).std()
            cnt_map = src.groupby(key_tr).count()
            g_mean = float(src.mean())
            g_std = float(src.std())
            for dfx, out in ((Xtr, tr), (Xva, va), (Xte, te)):
                key = dfx[g].astype(str)
                mu = key.map(mean_map).fillna(g_mean)
                sd = key.map(std_map).fillna(g_std)
                cnt = key.map(cnt_map).fillna(0.0)
                val = (dfx[n].astype(float).fillna(g_mean)
                       if n == "condition" else dfx[n].astype(float))
                out[f"gs_{g}_{n}_mu"] = mu
                out[f"gs_{g}_{n}_dev"] = val - mu
                out[f"gs_{g}_{n}_cnt"] = cnt
    return tr, va, te
